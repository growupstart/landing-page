
# PostHog 

<a href="https://posthog.com/"><img src="https://icons.duckduckgo.com/ip3/posthog.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/PostHog/posthog.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/PostHog/posthog/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/PostHog/posthog.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/PostHog/posthog/network/) [![GitHub issues](https://img.shields.io/github/issues/PostHog/posthog.svg)](https://GitHub.com/NPostHog/posthog/issues/)

[![GitHub license](https://img.shields.io/github/license/PostHog/posthog.svg)](https://github.com/PostHog/posthog/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/PostHog/posthog.svg)](https://GitHub.com/PostHog/posthog/graphs/contributors/) 

**Category**: Product Analytics

**Github**: [PostHog/posthog](https://github.com/PostHog/posthog)

**Website**: [posthog.com](https://posthog.com/)

**Description**:
Product analytics platform

**Alternative to**: [Amplitude](https://amplitude.com/), [MixPanel](https://mixpanel.com/)
