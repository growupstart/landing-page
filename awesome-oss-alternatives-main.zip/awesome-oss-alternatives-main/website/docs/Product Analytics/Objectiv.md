
# Objectiv 

<a href="https://objectiv.io/"><img src="https://icons.duckduckgo.com/ip3/objectiv.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/objectiv/objectiv-analytics.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/objectiv/objectiv-analytics/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/objectiv/objectiv-analytics.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/objectiv/objectiv-analytics/network/) [![GitHub issues](https://img.shields.io/github/issues/objectiv/objectiv-analytics.svg)](https://GitHub.com/Nobjectiv/objectiv-analytics/issues/)

[![GitHub license](https://img.shields.io/github/license/objectiv/objectiv-analytics.svg)](https://github.com/objectiv/objectiv-analytics/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/objectiv/objectiv-analytics.svg)](https://GitHub.com/objectiv/objectiv-analytics/graphs/contributors/) 

**Category**: Product Analytics

**Github**: [objectiv/objectiv-analytics](https://github.com/objectiv/objectiv-analytics)

**Website**: [objectiv.io](https://objectiv.io/)

**Description**:
Product analytics infrastructure

**Alternative to**: [Google Analytics](https://analytics.google.com/analytics/web/), [Amplitude](https://amplitude.com/), [Mixpanel](https://mixpanel.com/)
