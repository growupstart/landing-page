
# Metabase 

<a href="https://www.metabase.com/"><img src="https://icons.duckduckgo.com/ip3/www.metabase.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/metabase/metabase.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/metabase/metabase/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/metabase/metabase.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/metabase/metabase/network/) [![GitHub issues](https://img.shields.io/github/issues/metabase/metabase.svg)](https://GitHub.com/Nmetabase/metabase/issues/)

[![GitHub license](https://img.shields.io/github/license/metabase/metabase.svg)](https://github.com/metabase/metabase/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/metabase/metabase.svg)](https://GitHub.com/metabase/metabase/graphs/contributors/) 

**Category**: Business Intelligence

**Github**: [metabase/metabase](https://github.com/metabase/metabase)

**Website**: [www.metabase.com](https://www.metabase.com/)

**Description**:
Business intelligence software

**Alternative to**: [Tableau](https://www.tableau.com/), [Power BI](https://powerbi.microsoft.com/), [DataStudio](https://datastudio.google.com/)
