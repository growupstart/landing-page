
# Rudderstack 

<a href="https://rudderstack.com/"><img src="https://icons.duckduckgo.com/ip3/rudderstack.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/rudderlabs/rudder-server.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/rudderlabs/rudder-server/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/rudderlabs/rudder-server.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/rudderlabs/rudder-server/network/) [![GitHub issues](https://img.shields.io/github/issues/rudderlabs/rudder-server.svg)](https://GitHub.com/Nrudderlabs/rudder-server/issues/)

[![GitHub license](https://img.shields.io/github/license/rudderlabs/rudder-server.svg)](https://github.com/rudderlabs/rudder-server/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/rudderlabs/rudder-server.svg)](https://GitHub.com/rudderlabs/rudder-server/graphs/contributors/) 

**Category**: Customer Data Platform

**Github**: [rudderlabs/rudder-server](https://github.com/rudderlabs/rudder-server)

**Website**: [rudderstack.com](https://rudderstack.com/)

**Description**:
Customer data platform for developers

**Alternative to**: [Segment](https://segment.com/)
