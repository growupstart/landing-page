
# Jitsu 

<a href="https://jitsu.com/"><img src="https://icons.duckduckgo.com/ip3/jitsu.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/jitsucom/jitsu.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/jitsucom/jitsu/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/jitsucom/jitsu.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/jitsucom/jitsu/network/) [![GitHub issues](https://img.shields.io/github/issues/jitsucom/jitsu.svg)](https://GitHub.com/Njitsucom/jitsu/issues/)

[![GitHub license](https://img.shields.io/github/license/jitsucom/jitsu.svg)](https://github.com/jitsucom/jitsu/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/jitsucom/jitsu.svg)](https://GitHub.com/jitsucom/jitsu/graphs/contributors/) 

**Category**: Customer Data Platform

**Github**: [jitsucom/jitsu](https://github.com/jitsucom/jitsu)

**Website**: [jitsu.com](https://jitsu.com/)

**Description**:
Fully-scriptable data ingestion engine for modern data teams

**Alternative to**: [Segment](https://segment.com/)
