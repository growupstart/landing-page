
# Tracardi 

<a href="http://www.tracardi.com/"><img src="https://icons.duckduckgo.com/ip3/www.tracardi.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/tracardi/tracardi.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/tracardi/tracardi/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/tracardi/tracardi.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/tracardi/tracardi/network/) [![GitHub issues](https://img.shields.io/github/issues/tracardi/tracardi.svg)](https://GitHub.com/Ntracardi/tracardi/issues/)

[![GitHub license](https://img.shields.io/github/license/tracardi/tracardi.svg)](https://github.com/tracardi/tracardi/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/tracardi/tracardi.svg)](https://GitHub.com/tracardi/tracardi/graphs/contributors/) 

**Category**: Customer Data Platform

**Github**: [tracardi/tracardi](https://github.com/tracardi/tracardi)

**Website**: [www.tracardi.com](http://www.tracardi.com/)

**Description**:
Customer Data Platform with Consumer Journey automation engine

**Alternative to**: [Segment](https://segment.com/), [Zapier](https://zapier.com/)
