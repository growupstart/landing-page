
# Jitsi 

<a href="https://jitsi.org/meet"><img src="https://icons.duckduckgo.com/ip3/jitsi.org/meet.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/jitsi/jitsi-meet.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/jitsi/jitsi-meet/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/jitsi/jitsi-meet.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/jitsi/jitsi-meet/network/) [![GitHub issues](https://img.shields.io/github/issues/jitsi/jitsi-meet.svg)](https://GitHub.com/Njitsi/jitsi-meet/issues/)

[![GitHub license](https://img.shields.io/github/license/jitsi/jitsi-meet.svg)](https://github.com/jitsi/jitsi-meet/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/jitsi/jitsi-meet.svg)](https://GitHub.com/jitsi/jitsi-meet/graphs/contributors/) 

**Category**: Video Conferencing

**Github**: [jitsi/jitsi-meet](https://github.com/jitsi/jitsi-meet)

**Website**: [jitsi.org/meet](https://jitsi.org/meet)

**Description**:
Video conferences platform and SDK

**Alternative to**: [Zoom](https://zoom.us/)
