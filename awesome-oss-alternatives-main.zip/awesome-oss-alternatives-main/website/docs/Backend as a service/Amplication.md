
# Amplication 

<a href="https://amplication.com/"><img src="https://icons.duckduckgo.com/ip3/amplication.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/amplication/amplication.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/amplication/amplication/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/amplication/amplication.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/amplication/amplication/network/) [![GitHub issues](https://img.shields.io/github/issues/amplication/amplication.svg)](https://GitHub.com/Namplication/amplication/issues/)

[![GitHub license](https://img.shields.io/github/license/amplication/amplication.svg)](https://github.com/amplication/amplication/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/amplication/amplication.svg)](https://GitHub.com/amplication/amplication/graphs/contributors/) 

**Category**: Backend as a service

**Github**: [amplication/amplication](https://github.com/amplication/amplication)

**Website**: [amplication.com](https://amplication.com/)

**Description**:
Backend server with REST and GraphQL APIs to manage core backend needs

**Alternative to**: [Firebase](https://firebase.google.com/)
