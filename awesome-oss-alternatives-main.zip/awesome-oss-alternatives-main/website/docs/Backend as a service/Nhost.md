
# Nhost 

<a href="https://nhost.io/"><img src="https://icons.duckduckgo.com/ip3/nhost.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/nhost/nhost.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/nhost/nhost/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/nhost/nhost.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/nhost/nhost/network/) [![GitHub issues](https://img.shields.io/github/issues/nhost/nhost.svg)](https://GitHub.com/Nnhost/nhost/issues/)

[![GitHub license](https://img.shields.io/github/license/nhost/nhost.svg)](https://github.com/nhost/nhost/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/nhost/nhost.svg)](https://GitHub.com/nhost/nhost/graphs/contributors/) 

**Category**: Backend as a service

**Github**: [nhost/nhost](https://github.com/nhost/nhost)

**Website**: [nhost.io](https://nhost.io/)

**Description**:
Backend server with GraphQL

**Alternative to**: [Firebase](https://firebase.google.com/)
