
# Strapi 

<a href="https://strapi.io/"><img src="https://icons.duckduckgo.com/ip3/strapi.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/strapi/strapi.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/strapi/strapi/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/strapi/strapi.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/strapi/strapi/network/) [![GitHub issues](https://img.shields.io/github/issues/strapi/strapi.svg)](https://GitHub.com/Nstrapi/strapi/issues/)

[![GitHub license](https://img.shields.io/github/license/strapi/strapi.svg)](https://github.com/strapi/strapi/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/strapi/strapi.svg)](https://GitHub.com/strapi/strapi/graphs/contributors/) 

**Category**: CMS

**Github**: [strapi/strapi](https://github.com/strapi/strapi)

**Website**: [strapi.io](https://strapi.io/)

**Description**:
Node.js Headless CMS to build customisable APIs

**Alternative to**: [Contentful](https://www.contentful.com/)
