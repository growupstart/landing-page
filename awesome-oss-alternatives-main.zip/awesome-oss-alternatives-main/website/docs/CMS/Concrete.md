
# Concrete 

<a href="https://www.concretecms.com/"><img src="https://icons.duckduckgo.com/ip3/www.concretecms.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/concrete5/concrete5.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/concrete5/concrete5/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/concrete5/concrete5.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/concrete5/concrete5/network/) [![GitHub issues](https://img.shields.io/github/issues/concrete5/concrete5.svg)](https://GitHub.com/Nconcrete5/concrete5/issues/)

[![GitHub license](https://img.shields.io/github/license/concrete5/concrete5.svg)](https://github.com/concrete5/concrete5/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/concrete5/concrete5.svg)](https://GitHub.com/concrete5/concrete5/graphs/contributors/) 

**Category**: CMS

**Github**: [concrete5/concrete5](https://github.com/concrete5/concrete5)

**Website**: [www.concretecms.com](https://www.concretecms.com/)

**Description**:
CMS for teams

**Alternative to**: [Contentful](https://www.contentful.com/)
