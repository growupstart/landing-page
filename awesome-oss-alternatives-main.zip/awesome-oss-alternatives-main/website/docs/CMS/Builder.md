
# Builder 

<a href="https://builder.io/"><img src="https://icons.duckduckgo.com/ip3/builder.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/builderio/builder.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/builderio/builder/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/builderio/builder.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/builderio/builder/network/) [![GitHub issues](https://img.shields.io/github/issues/builderio/builder.svg)](https://GitHub.com/Nbuilderio/builder/issues/)

[![GitHub license](https://img.shields.io/github/license/builderio/builder.svg)](https://github.com/builderio/builder/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/builderio/builder.svg)](https://GitHub.com/builderio/builder/graphs/contributors/) 

**Category**: CMS

**Github**: [builderio/builder](https://github.com/builderio/builder)

**Website**: [builder.io](https://builder.io/)

**Description**:
Drag and drop page builder and CMS

**Alternative to**: [Contentful](https://www.contentful.com/)
