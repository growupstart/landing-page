
# Plasmic 

<a href="https://plasmic.app/"><img src="https://icons.duckduckgo.com/ip3/plasmic.app.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/plasmicapp/plasmic.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/plasmicapp/plasmic/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/plasmicapp/plasmic.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/plasmicapp/plasmic/network/) [![GitHub issues](https://img.shields.io/github/issues/plasmicapp/plasmic.svg)](https://GitHub.com/Nplasmicapp/plasmic/issues/)

[![GitHub license](https://img.shields.io/github/license/plasmicapp/plasmic.svg)](https://github.com/plasmicapp/plasmic/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/plasmicapp/plasmic.svg)](https://GitHub.com/plasmicapp/plasmic/graphs/contributors/) 

**Category**: CMS

**Github**: [plasmicapp/plasmic](https://github.com/plasmicapp/plasmic)

**Website**: [plasmic.app](https://plasmic.app/)

**Description**:
The headless page builder for singe-page frameworks

**Alternative to**: [Contentful](https://www.contentful.com/)
