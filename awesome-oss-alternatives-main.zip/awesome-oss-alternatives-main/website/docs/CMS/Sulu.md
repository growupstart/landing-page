
# Sulu 

<a href="https://sulu.io/"><img src="https://icons.duckduckgo.com/ip3/sulu.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/sulu/sulu.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/sulu/sulu/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/sulu/sulu.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/sulu/sulu/network/) [![GitHub issues](https://img.shields.io/github/issues/sulu/sulu.svg)](https://GitHub.com/Nsulu/sulu/issues/)

[![GitHub license](https://img.shields.io/github/license/sulu/sulu.svg)](https://github.com/sulu/sulu/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/sulu/sulu.svg)](https://GitHub.com/sulu/sulu/graphs/contributors/) 

**Category**: CMS

**Github**: [sulu/sulu](https://github.com/sulu/sulu)

**Website**: [sulu.io](https://sulu.io/)

**Description**:
Modern Symfony based CMS

**Alternative to**: [Contentful](https://www.contentful.com/)
