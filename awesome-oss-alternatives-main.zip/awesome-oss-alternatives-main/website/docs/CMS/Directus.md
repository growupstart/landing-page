
# Directus 

<a href="https://directus.io/"><img src="https://icons.duckduckgo.com/ip3/directus.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/directus/directus.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/directus/directus/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/directus/directus.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/directus/directus/network/) [![GitHub issues](https://img.shields.io/github/issues/directus/directus.svg)](https://GitHub.com/Ndirectus/directus/issues/)

[![GitHub license](https://img.shields.io/github/license/directus/directus.svg)](https://github.com/directus/directus/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/directus/directus.svg)](https://GitHub.com/directus/directus/graphs/contributors/) 

**Category**: CMS

**Github**: [directus/directus](https://github.com/directus/directus)

**Website**: [directus.io](https://directus.io/)

**Description**:
Data platform which wraps any database with an intuitive app

**Alternative to**: [Contentful](https://www.contentful.com/)
