
# Tina 

<a href="https://tina.io/"><img src="https://icons.duckduckgo.com/ip3/tina.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/tinacms/tinacms.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/tinacms/tinacms/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/tinacms/tinacms.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/tinacms/tinacms/network/) [![GitHub issues](https://img.shields.io/github/issues/tinacms/tinacms.svg)](https://GitHub.com/Ntinacms/tinacms/issues/)

[![GitHub license](https://img.shields.io/github/license/tinacms/tinacms.svg)](https://github.com/tinacms/tinacms/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/tinacms/tinacms.svg)](https://GitHub.com/tinacms/tinacms/graphs/contributors/) 

**Category**: CMS

**Github**: [tinacms/tinacms](https://github.com/tinacms/tinacms)

**Website**: [tina.io](https://tina.io/)

**Description**:
Visual editor for React websites

**Alternative to**: [Contentful](https://www.contentful.com/)
