
# OpenReplay 

<a href="https://openreplay.com/"><img src="https://icons.duckduckgo.com/ip3/openreplay.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/openreplay/openreplay.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/openreplay/openreplay/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/openreplay/openreplay.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/openreplay/openreplay/network/) [![GitHub issues](https://img.shields.io/github/issues/openreplay/openreplay.svg)](https://GitHub.com/Nopenreplay/openreplay/issues/)

[![GitHub license](https://img.shields.io/github/license/openreplay/openreplay.svg)](https://github.com/openreplay/openreplay/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/openreplay/openreplay.svg)](https://GitHub.com/openreplay/openreplay/graphs/contributors/) 

**Category**: Session replay software

**Github**: [openreplay/openreplay](https://github.com/openreplay/openreplay)

**Website**: [openreplay.com](https://openreplay.com/)

**Description**:
Session replay stack for developers

**Alternative to**: [LogRocket](https://logrocket.com/), [FullStory](https://www.fullstory.com/)
