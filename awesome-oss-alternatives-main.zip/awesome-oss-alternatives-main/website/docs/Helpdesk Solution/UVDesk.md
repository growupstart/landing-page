
# UVDesk 

<a href="https://www.uvdesk.com/en/"><img src="https://icons.duckduckgo.com/ip3/www.uvdesk.com/en.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/uvdesk/community-skeleton.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/uvdesk/community-skeleton/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/uvdesk/community-skeleton.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/uvdesk/community-skeleton/network/) [![GitHub issues](https://img.shields.io/github/issues/uvdesk/community-skeleton.svg)](https://GitHub.com/Nuvdesk/community-skeleton/issues/)

[![GitHub license](https://img.shields.io/github/license/uvdesk/community-skeleton.svg)](https://github.com/uvdesk/community-skeleton/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/uvdesk/community-skeleton.svg)](https://GitHub.com/uvdesk/community-skeleton/graphs/contributors/) 

**Category**: Helpdesk Solution

**Github**: [uvdesk/community-skeleton](https://github.com/uvdesk/community-skeleton)

**Website**: [www.uvdesk.com/en](https://www.uvdesk.com/en/)

**Description**:
Ticket Management & Helpdesk system

**Alternative to**: [Zendesk](https://www.zendesk.co.uk/)
