
# Peppermint 

<a href="https://peppermint.sh"><img src="https://icons.duckduckgo.com/ip3/peppermint.sh.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Peppermint-Lab/peppermint.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Peppermint-Lab/peppermint/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Peppermint-Lab/peppermint.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Peppermint-Lab/peppermint/network/) [![GitHub issues](https://img.shields.io/github/issues/Peppermint-Lab/peppermint.svg)](https://GitHub.com/NPeppermint-Lab/peppermint/issues/)

[![GitHub license](https://img.shields.io/github/license/Peppermint-Lab/peppermint.svg)](https://github.com/Peppermint-Lab/peppermint/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Peppermint-Lab/peppermint.svg)](https://GitHub.com/Peppermint-Lab/peppermint/graphs/contributors/) 

**Category**: Helpdesk Solution

**Github**: [Peppermint-Lab/peppermint](https://github.com/Peppermint-Lab/peppermint)

**Website**: [peppermint.sh](https://peppermint.sh)

**Description**:
Ticket Management & Helpdesk system

**Alternative to**: [Zendesk](https://www.zendesk.co.uk/)
