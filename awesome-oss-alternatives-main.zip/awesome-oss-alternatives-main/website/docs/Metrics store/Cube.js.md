
# Cube.js 

<a href="https://cube.dev/"><img src="https://icons.duckduckgo.com/ip3/cube.dev.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/cube-js/cube.js.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/cube-js/cube.js/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/cube-js/cube.js.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/cube-js/cube.js/network/) [![GitHub issues](https://img.shields.io/github/issues/cube-js/cube.js.svg)](https://GitHub.com/Ncube-js/cube.js/issues/)

[![GitHub license](https://img.shields.io/github/license/cube-js/cube.js.svg)](https://github.com/cube-js/cube.js/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/cube-js/cube.js.svg)](https://GitHub.com/cube-js/cube.js/graphs/contributors/) 

**Category**: Metrics store

**Github**: [cube-js/cube.js](https://github.com/cube-js/cube.js)

**Website**: [cube.dev](https://cube.dev/)

**Description**:
Headless business intelligence suite

**Alternative to**: [Looker](https://looker.com/)
