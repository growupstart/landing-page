
# LightDash 

<a href="https://www.lightdash.com/"><img src="https://icons.duckduckgo.com/ip3/www.lightdash.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/lightdash/lightdash.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/lightdash/lightdash/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/lightdash/lightdash.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/lightdash/lightdash/network/) [![GitHub issues](https://img.shields.io/github/issues/lightdash/lightdash.svg)](https://GitHub.com/Nlightdash/lightdash/issues/)

[![GitHub license](https://img.shields.io/github/license/lightdash/lightdash.svg)](https://github.com/lightdash/lightdash/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/lightdash/lightdash.svg)](https://GitHub.com/lightdash/lightdash/graphs/contributors/) 

**Category**: Metrics store

**Github**: [lightdash/lightdash](https://github.com/lightdash/lightdash)

**Website**: [www.lightdash.com](https://www.lightdash.com/)

**Description**:
Low-code metrics layer, alternative to Looker

**Alternative to**: [Looker](https://looker.com/)
