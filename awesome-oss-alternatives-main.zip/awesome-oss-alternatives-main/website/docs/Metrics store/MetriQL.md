
# MetriQL 

<a href="https://metriql.com/"><img src="https://icons.duckduckgo.com/ip3/metriql.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/metriql/metriql.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/metriql/metriql/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/metriql/metriql.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/metriql/metriql/network/) [![GitHub issues](https://img.shields.io/github/issues/metriql/metriql.svg)](https://GitHub.com/Nmetriql/metriql/issues/)

[![GitHub license](https://img.shields.io/github/license/metriql/metriql.svg)](https://github.com/metriql/metriql/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/metriql/metriql.svg)](https://GitHub.com/metriql/metriql/graphs/contributors/) 

**Category**: Metrics store

**Github**: [metriql/metriql](https://github.com/metriql/metriql)

**Website**: [metriql.com](https://metriql.com/)

**Description**:
Headless business intelligence suite

**Alternative to**: [Looker](https://looker.com/)
