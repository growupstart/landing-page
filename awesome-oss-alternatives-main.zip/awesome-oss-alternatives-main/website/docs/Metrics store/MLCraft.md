
# MLCraft 

<a href="http://mlcraft.io/"><img src="https://icons.duckduckgo.com/ip3/mlcraft.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/mlcraft-io/mlcraft.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/mlcraft-io/mlcraft/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/mlcraft-io/mlcraft.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/mlcraft-io/mlcraft/network/) [![GitHub issues](https://img.shields.io/github/issues/mlcraft-io/mlcraft.svg)](https://GitHub.com/Nmlcraft-io/mlcraft/issues/)

[![GitHub license](https://img.shields.io/github/license/mlcraft-io/mlcraft.svg)](https://github.com/mlcraft-io/mlcraft/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/mlcraft-io/mlcraft.svg)](https://GitHub.com/mlcraft-io/mlcraft/graphs/contributors/) 

**Category**: Metrics store

**Github**: [mlcraft-io/mlcraft](https://github.com/mlcraft-io/mlcraft)

**Website**: [mlcraft.io](http://mlcraft.io/)

**Description**:
Low-code metrics layer, alternative to Looker

**Alternative to**: [Looker](https://looker.com/)
