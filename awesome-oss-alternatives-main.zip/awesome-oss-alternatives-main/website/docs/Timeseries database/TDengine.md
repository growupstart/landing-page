
# TDengine 

<a href="https://tdengine.com/?en"><img src="https://icons.duckduckgo.com/ip3/tdengine.com/?en.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/taosdata/TDengine.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/taosdata/TDengine/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/taosdata/TDengine.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/taosdata/TDengine/network/) [![GitHub issues](https://img.shields.io/github/issues/taosdata/TDengine.svg)](https://GitHub.com/Ntaosdata/TDengine/issues/)

[![GitHub license](https://img.shields.io/github/license/taosdata/TDengine.svg)](https://github.com/taosdata/TDengine/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/taosdata/TDengine.svg)](https://GitHub.com/taosdata/TDengine/graphs/contributors/) 

**Category**: Timeseries database

**Github**: [taosdata/TDengine](https://github.com/taosdata/TDengine)

**Website**: [tdengine.com/?en](https://tdengine.com/?en)

**Description**:
Database designed to process time series data

**Alternative to**: [Kdb+](https://kx.com/developers/)
