
# Grouparoo 

<a href="https://www.grouparoo.com/"><img src="https://icons.duckduckgo.com/ip3/www.grouparoo.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/grouparoo/grouparoo.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/grouparoo/grouparoo/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/grouparoo/grouparoo.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/grouparoo/grouparoo/network/) [![GitHub issues](https://img.shields.io/github/issues/grouparoo/grouparoo.svg)](https://GitHub.com/Ngrouparoo/grouparoo/issues/)

[![GitHub license](https://img.shields.io/github/license/grouparoo/grouparoo.svg)](https://github.com/grouparoo/grouparoo/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/grouparoo/grouparoo.svg)](https://GitHub.com/grouparoo/grouparoo/graphs/contributors/) 

**Category**: Reverse ETL

**Github**: [grouparoo/grouparoo](https://github.com/grouparoo/grouparoo)

**Website**: [www.grouparoo.com](https://www.grouparoo.com/)

**Description**:
Data synchronization framework

**Alternative to**: [Hightouch](https://www.hightouch.io/)
