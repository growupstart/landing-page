
# Chaskiq 

<a href="https://chaskiq.io/"><img src="https://icons.duckduckgo.com/ip3/chaskiq.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/chaskiq/chaskiq.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/chaskiq/chaskiq/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/chaskiq/chaskiq.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/chaskiq/chaskiq/network/) [![GitHub issues](https://img.shields.io/github/issues/chaskiq/chaskiq.svg)](https://GitHub.com/Nchaskiq/chaskiq/issues/)

[![GitHub license](https://img.shields.io/github/license/chaskiq/chaskiq.svg)](https://github.com/chaskiq/chaskiq/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/chaskiq/chaskiq.svg)](https://GitHub.com/chaskiq/chaskiq/graphs/contributors/) 

**Category**: Customer Engagement

**Github**: [chaskiq/chaskiq](https://github.com/chaskiq/chaskiq)

**Website**: [chaskiq.io](https://chaskiq.io/)

**Description**:
Live chat widget

**Alternative to**: [Intercom](https://www.intercom.com/), [Zendesk](https://www.zendesk.com/)
