
# Chatwoot 

<a href="https://www.chatwoot.com/"><img src="https://icons.duckduckgo.com/ip3/www.chatwoot.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/chatwoot/chatwoot.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/chatwoot/chatwoot/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/chatwoot/chatwoot.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/chatwoot/chatwoot/network/) [![GitHub issues](https://img.shields.io/github/issues/chatwoot/chatwoot.svg)](https://GitHub.com/Nchatwoot/chatwoot/issues/)

[![GitHub license](https://img.shields.io/github/license/chatwoot/chatwoot.svg)](https://github.com/chatwoot/chatwoot/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/chatwoot/chatwoot.svg)](https://GitHub.com/chatwoot/chatwoot/graphs/contributors/) 

**Category**: Customer Engagement

**Github**: [chatwoot/chatwoot](https://github.com/chatwoot/chatwoot)

**Website**: [www.chatwoot.com](https://www.chatwoot.com/)

**Description**:
Live chat widget

**Alternative to**: [Intercom](https://www.intercom.com/), [Zendesk](https://www.zendesk.com/)
