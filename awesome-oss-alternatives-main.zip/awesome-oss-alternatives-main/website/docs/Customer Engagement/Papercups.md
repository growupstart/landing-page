
# Papercups 

<a href="https://papercups.io/"><img src="https://icons.duckduckgo.com/ip3/papercups.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/papercups-io/papercups.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/papercups-io/papercups/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/papercups-io/papercups.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/papercups-io/papercups/network/) [![GitHub issues](https://img.shields.io/github/issues/papercups-io/papercups.svg)](https://GitHub.com/Npapercups-io/papercups/issues/)

[![GitHub license](https://img.shields.io/github/license/papercups-io/papercups.svg)](https://github.com/papercups-io/papercups/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/papercups-io/papercups.svg)](https://GitHub.com/papercups-io/papercups/graphs/contributors/) 

**Category**: Customer Engagement

**Github**: [papercups-io/papercups](https://github.com/papercups-io/papercups)

**Website**: [papercups.io](https://papercups.io/)

**Description**:
Live chat widget

**Alternative to**: [Intercom](https://www.intercom.com/), [Zendesk](https://www.zendesk.com/)
