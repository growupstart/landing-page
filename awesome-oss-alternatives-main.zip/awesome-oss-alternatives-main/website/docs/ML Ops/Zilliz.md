
# Zilliz 

<a href="https://zilliz.com)'s [Towhe"><img src="https://icons.duckduckgo.com/ip3/zilliz.com)'s [Towhe.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/towhee-io/towhee.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/towhee-io/towhee/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/towhee-io/towhee.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/towhee-io/towhee/network/) [![GitHub issues](https://img.shields.io/github/issues/towhee-io/towhee.svg)](https://GitHub.com/Ntowhee-io/towhee/issues/)

[![GitHub license](https://img.shields.io/github/license/towhee-io/towhee.svg)](https://github.com/towhee-io/towhee/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/towhee-io/towhee.svg)](https://GitHub.com/towhee-io/towhee/graphs/contributors/) 

**Category**: ML Ops

**Github**: [towhee-io/towhee](https://github.com/towhee-io/towhee)

**Website**: [zilliz.com)'s [Towhe](https://zilliz.com)'s [Towhe)

**Description**:
Platform for generating embedding vectors

**Alternative to**: [AWS SageMaker](https://aws.amazon.com/sagemaker)
