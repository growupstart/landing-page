
# AppSmith 

<a href="https://www.appsmith.com/"><img src="https://icons.duckduckgo.com/ip3/www.appsmith.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/appsmithorg/appsmith.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/appsmithorg/appsmith/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/appsmithorg/appsmith.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/appsmithorg/appsmith/network/) [![GitHub issues](https://img.shields.io/github/issues/appsmithorg/appsmith.svg)](https://GitHub.com/Nappsmithorg/appsmith/issues/)

[![GitHub license](https://img.shields.io/github/license/appsmithorg/appsmith.svg)](https://github.com/appsmithorg/appsmith/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/appsmithorg/appsmith.svg)](https://GitHub.com/appsmithorg/appsmith/graphs/contributors/) 

**Category**: Internal Tools

**Github**: [appsmithorg/appsmith](https://github.com/appsmithorg/appsmith)

**Website**: [www.appsmith.com](https://www.appsmith.com/)

**Description**:
Low-code platform for internal tools

**Alternative to**: [Retool](https://retool.com/)
