
# Lowdefy 

<a href="https://lowdefy.com/"><img src="https://icons.duckduckgo.com/ip3/lowdefy.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/lowdefy/lowdefy.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/lowdefy/lowdefy/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/lowdefy/lowdefy.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/lowdefy/lowdefy/network/) [![GitHub issues](https://img.shields.io/github/issues/lowdefy/lowdefy.svg)](https://GitHub.com/Nlowdefy/lowdefy/issues/)

[![GitHub license](https://img.shields.io/github/license/lowdefy/lowdefy.svg)](https://github.com/lowdefy/lowdefy/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/lowdefy/lowdefy.svg)](https://GitHub.com/lowdefy/lowdefy/graphs/contributors/) 

**Category**: Internal Tools

**Github**: [lowdefy/lowdefy](https://github.com/lowdefy/lowdefy)

**Website**: [lowdefy.com](https://lowdefy.com/)

**Description**:
YAML-based low-code platform for internal tools

**Alternative to**: [Retool](https://retool.com/)
