
# Budibase 

<a href="https://budibase.com/"><img src="https://icons.duckduckgo.com/ip3/budibase.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Budibase/budibase.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Budibase/budibase/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Budibase/budibase.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Budibase/budibase/network/) [![GitHub issues](https://img.shields.io/github/issues/Budibase/budibase.svg)](https://GitHub.com/NBudibase/budibase/issues/)

[![GitHub license](https://img.shields.io/github/license/Budibase/budibase.svg)](https://github.com/Budibase/budibase/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Budibase/budibase.svg)](https://GitHub.com/Budibase/budibase/graphs/contributors/) 

**Category**: Internal Tools

**Github**: [Budibase/budibase](https://github.com/Budibase/budibase)

**Website**: [budibase.com](https://budibase.com/)

**Description**:
Low-code platform for internal tools

**Alternative to**: [Retool](https://retool.com/)
