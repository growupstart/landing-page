
# Penpot 

<a href="https://penpot.app/"><img src="https://icons.duckduckgo.com/ip3/penpot.app.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/penpot/penpot.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/penpot/penpot/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/penpot/penpot.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/penpot/penpot/network/) [![GitHub issues](https://img.shields.io/github/issues/penpot/penpot.svg)](https://GitHub.com/Npenpot/penpot/issues/)

[![GitHub license](https://img.shields.io/github/license/penpot/penpot.svg)](https://github.com/penpot/penpot/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/penpot/penpot.svg)](https://GitHub.com/penpot/penpot/graphs/contributors/) 

**Category**: Design

**Github**: [penpot/penpot](https://github.com/penpot/penpot)

**Website**: [penpot.app](https://penpot.app/)

**Description**:
Design & prototyping platform

**Alternative to**: [Figma](https://www.figma.com/)
