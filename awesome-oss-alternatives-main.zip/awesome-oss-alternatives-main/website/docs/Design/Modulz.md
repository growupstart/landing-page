
# Modulz 

<a href="https://www.modulz.app/"><img src="https://icons.duckduckgo.com/ip3/www.modulz.app.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/radix-ui/primitives.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/radix-ui/primitives/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/radix-ui/primitives.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/radix-ui/primitives/network/) [![GitHub issues](https://img.shields.io/github/issues/radix-ui/primitives.svg)](https://GitHub.com/Nradix-ui/primitives/issues/)

[![GitHub license](https://img.shields.io/github/license/radix-ui/primitives.svg)](https://github.com/radix-ui/primitives/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/radix-ui/primitives.svg)](https://GitHub.com/radix-ui/primitives/graphs/contributors/) 

**Category**: Design

**Github**: [radix-ui/primitives](https://github.com/radix-ui/primitives)

**Website**: [www.modulz.app](https://www.modulz.app/)

**Description**:
Code-based tool for designing and prototyping

**Alternative to**: [Figma](https://www.figma.com/)
