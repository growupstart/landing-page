
# Baserow 

<a href="https://baserow.io/"><img src="https://icons.duckduckgo.com/ip3/baserow.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/https://gitlab.com/bramw/baserow.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/https://gitlab.com/bramw/baserow/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/https://gitlab.com/bramw/baserow.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/https://gitlab.com/bramw/baserow/network/) [![GitHub issues](https://img.shields.io/github/issues/https://gitlab.com/bramw/baserow.svg)](https://GitHub.com/Nhttps://gitlab.com/bramw/baserow/issues/)

[![GitHub license](https://img.shields.io/github/license/https://gitlab.com/bramw/baserow.svg)](https://github.com/https://gitlab.com/bramw/baserow/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/https://gitlab.com/bramw/baserow.svg)](https://GitHub.com/https://gitlab.com/bramw/baserow/graphs/contributors/) 

**Category**: No-code database

**Github**: [https://gitlab.com/bramw/baserow](https://gitlab.com/bramw/baserow)

**Website**: [baserow.io](https://baserow.io/)

**Description**:
No-code database and Airtable alternative

**Alternative to**: [AirTable](https://www.airtable.com/)
