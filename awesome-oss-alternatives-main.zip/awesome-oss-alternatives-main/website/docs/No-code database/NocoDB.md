
# NocoDB 

<a href="https://www.nocodb.com/"><img src="https://icons.duckduckgo.com/ip3/www.nocodb.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/nocodb/nocodb.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/nocodb/nocodb/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/nocodb/nocodb.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/nocodb/nocodb/network/) [![GitHub issues](https://img.shields.io/github/issues/nocodb/nocodb.svg)](https://GitHub.com/Nnocodb/nocodb/issues/)

[![GitHub license](https://img.shields.io/github/license/nocodb/nocodb.svg)](https://github.com/nocodb/nocodb/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/nocodb/nocodb.svg)](https://GitHub.com/nocodb/nocodb/graphs/contributors/) 

**Category**: No-code database

**Github**: [nocodb/nocodb](https://github.com/nocodb/nocodb)

**Website**: [www.nocodb.com](https://www.nocodb.com/)

**Description**:
No-code database and Airtable alternative

**Alternative to**: [AirTable](https://www.airtable.com/)
