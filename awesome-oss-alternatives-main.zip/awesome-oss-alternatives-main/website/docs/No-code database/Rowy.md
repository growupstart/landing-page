
# Rowy 

<a href="https://www.rowy.io/"><img src="https://icons.duckduckgo.com/ip3/www.rowy.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/rowyio/rowy.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/rowyio/rowy/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/rowyio/rowy.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/rowyio/rowy/network/) [![GitHub issues](https://img.shields.io/github/issues/rowyio/rowy.svg)](https://GitHub.com/Nrowyio/rowy/issues/)

[![GitHub license](https://img.shields.io/github/license/rowyio/rowy.svg)](https://github.com/rowyio/rowy/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/rowyio/rowy.svg)](https://GitHub.com/rowyio/rowy/graphs/contributors/) 

**Category**: No-code database

**Github**: [rowyio/rowy](https://github.com/rowyio/rowy)

**Website**: [www.rowy.io](https://www.rowy.io/)

**Description**:
Extendable Airtable-like spreadsheet UI for databases

**Alternative to**: [AirTable](https://www.airtable.com/)
