
# Totum 

<a href="https://totum.online/"><img src="https://icons.duckduckgo.com/ip3/totum.online.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/totumonline/totum-mit.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/totumonline/totum-mit/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/totumonline/totum-mit.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/totumonline/totum-mit/network/) [![GitHub issues](https://img.shields.io/github/issues/totumonline/totum-mit.svg)](https://GitHub.com/Ntotumonline/totum-mit/issues/)

[![GitHub license](https://img.shields.io/github/license/totumonline/totum-mit.svg)](https://github.com/totumonline/totum-mit/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/totumonline/totum-mit.svg)](https://GitHub.com/totumonline/totum-mit/graphs/contributors/) 

**Category**: No-code database

**Github**: [totumonline/totum-mit](https://github.com/totumonline/totum-mit)

**Website**: [totum.online](https://totum.online/)

**Description**:
Business database for non-programmers

**Alternative to**: [AirTable](https://www.airtable.com/)
