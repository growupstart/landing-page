
# Element 

<a href="https://element.io/"><img src="https://icons.duckduckgo.com/ip3/element.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/vector-im/element-web.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/vector-im/element-web/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/vector-im/element-web.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/vector-im/element-web/network/) [![GitHub issues](https://img.shields.io/github/issues/vector-im/element-web.svg)](https://GitHub.com/Nvector-im/element-web/issues/)

[![GitHub license](https://img.shields.io/github/license/vector-im/element-web.svg)](https://github.com/vector-im/element-web/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/vector-im/element-web.svg)](https://GitHub.com/vector-im/element-web/graphs/contributors/) 

**Category**: Messaging

**Github**: [vector-im/element-web](https://github.com/vector-im/element-web)

**Website**: [element.io](https://element.io/)

**Description**:
Enterprise communication platform

**Alternative to**: [Slack](https://slack.com/)
