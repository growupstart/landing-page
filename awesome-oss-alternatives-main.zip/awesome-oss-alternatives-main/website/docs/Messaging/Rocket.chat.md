
# Rocket.chat 

<a href="https://rocket.chat/"><img src="https://icons.duckduckgo.com/ip3/rocket.chat.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/RocketChat/Rocket.Chat.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/RocketChat/Rocket.Chat/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/RocketChat/Rocket.Chat.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/RocketChat/Rocket.Chat/network/) [![GitHub issues](https://img.shields.io/github/issues/RocketChat/Rocket.Chat.svg)](https://GitHub.com/NRocketChat/Rocket.Chat/issues/)

[![GitHub license](https://img.shields.io/github/license/RocketChat/Rocket.Chat.svg)](https://github.com/RocketChat/Rocket.Chat/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/RocketChat/Rocket.Chat.svg)](https://GitHub.com/RocketChat/Rocket.Chat/graphs/contributors/) 

**Category**: Messaging

**Github**: [RocketChat/Rocket.Chat](https://github.com/RocketChat/Rocket.Chat)

**Website**: [rocket.chat](https://rocket.chat/)

**Description**:
Enterprise communication platform

**Alternative to**: [Slack](https://slack.com/)
