
# Tinode 

<a href="https://tinode.co/"><img src="https://icons.duckduckgo.com/ip3/tinode.co.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/tiode/chat.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/tiode/chat/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/tiode/chat.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/tiode/chat/network/) [![GitHub issues](https://img.shields.io/github/issues/tiode/chat.svg)](https://GitHub.com/Ntiode/chat/issues/)

[![GitHub license](https://img.shields.io/github/license/tiode/chat.svg)](https://github.com/tiode/chat/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/tiode/chat.svg)](https://GitHub.com/tiode/chat/graphs/contributors/) 

**Category**: Messaging

**Github**: [tiode/chat](https://github.com/tiode/chat)

**Website**: [tinode.co](https://tinode.co/)

**Description**:
General instant messaging

**Alternative to**: [WhatsApp](https://www.whatsapp.com/), [Telegram](https://www.telegram.org/)
