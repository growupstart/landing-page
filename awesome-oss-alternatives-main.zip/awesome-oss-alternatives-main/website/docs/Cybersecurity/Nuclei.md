
# Nuclei 

<a href="https://nuclei.projectdiscovery.io/"><img src="https://icons.duckduckgo.com/ip3/nuclei.projectdiscovery.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/projectdiscovery/nuclei.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/projectdiscovery/nuclei/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/projectdiscovery/nuclei.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/projectdiscovery/nuclei/network/) [![GitHub issues](https://img.shields.io/github/issues/projectdiscovery/nuclei.svg)](https://GitHub.com/Nprojectdiscovery/nuclei/issues/)

[![GitHub license](https://img.shields.io/github/license/projectdiscovery/nuclei.svg)](https://github.com/projectdiscovery/nuclei/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/projectdiscovery/nuclei.svg)](https://GitHub.com/projectdiscovery/nuclei/graphs/contributors/) 

**Category**: Cybersecurity

**Github**: [projectdiscovery/nuclei](https://github.com/projectdiscovery/nuclei)

**Website**: [nuclei.projectdiscovery.io](https://nuclei.projectdiscovery.io/)

**Description**:
Vulnerability scanner based on simple YAML based DSL

**Alternative to**: [Tenable Nessus](https://www.tenable.com/products/nessus)
