
# Firezone 

<a href="https://www.firez.one/"><img src="https://icons.duckduckgo.com/ip3/www.firez.one.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/firezone/firezone.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/firezone/firezone/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/firezone/firezone.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/firezone/firezone/network/) [![GitHub issues](https://img.shields.io/github/issues/firezone/firezone.svg)](https://GitHub.com/Nfirezone/firezone/issues/)

[![GitHub license](https://img.shields.io/github/license/firezone/firezone.svg)](https://github.com/firezone/firezone/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/firezone/firezone.svg)](https://GitHub.com/firezone/firezone/graphs/contributors/) 

**Category**: Cybersecurity

**Github**: [firezone/firezone](https://github.com/firezone/firezone)

**Website**: [www.firez.one](https://www.firez.one/)

**Description**:
VPN Server & Firewall for teams

**Alternative to**: [OpenVPN Access Server](https://openvpn.net/access-server/)
