
# DoliCloud 

<a href="https://dolicloud.com)"><img src="https://icons.duckduckgo.com/ip3/dolicloud.com).ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Dolibarr/dolibarr.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Dolibarr/dolibarr/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Dolibarr/dolibarr.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Dolibarr/dolibarr/network/) [![GitHub issues](https://img.shields.io/github/issues/Dolibarr/dolibarr.svg)](https://GitHub.com/NDolibarr/dolibarr/issues/)

[![GitHub license](https://img.shields.io/github/license/Dolibarr/dolibarr.svg)](https://github.com/Dolibarr/dolibarr/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Dolibarr/dolibarr.svg)](https://GitHub.com/Dolibarr/dolibarr/graphs/contributors/) 

**Category**: ERP

**Github**: [Dolibarr/dolibarr](https://github.com/Dolibarr/dolibarr)

**Website**: [dolicloud.com)](https://dolicloud.com))

**Description**:
 Business management suite (ERP and CRM)

**Alternative to**: [Oracle Fusion ERP Cloud](https://www.oracle.com/erp), [Odoo](https://odoo.com/), [Microsoft Dynamics](https://dynamics.microsoft.com/)
