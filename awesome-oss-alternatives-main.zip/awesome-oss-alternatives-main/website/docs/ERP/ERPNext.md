
# ERPNext 

<a href="https://erpnext.com)"><img src="https://icons.duckduckgo.com/ip3/erpnext.com).ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/frappe/erpnext.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/frappe/erpnext/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/frappe/erpnext.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/frappe/erpnext/network/) [![GitHub issues](https://img.shields.io/github/issues/frappe/erpnext.svg)](https://GitHub.com/Nfrappe/erpnext/issues/)

[![GitHub license](https://img.shields.io/github/license/frappe/erpnext.svg)](https://github.com/frappe/erpnext/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/frappe/erpnext.svg)](https://GitHub.com/frappe/erpnext/graphs/contributors/) 

**Category**: ERP

**Github**: [frappe/erpnext](https://github.com/frappe/erpnext)

**Website**: [erpnext.com)](https://erpnext.com))

**Description**:
 Agile, modern, module based Business management suite

**Alternative to**: [SAP Business One](https://www.sap.com/products/business-one.html), [Odoo](https://odoo.com/)
