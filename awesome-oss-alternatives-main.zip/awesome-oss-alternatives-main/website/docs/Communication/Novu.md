
# Novu 

<a href="https://novu.co/"><img src="https://icons.duckduckgo.com/ip3/novu.co.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/novuhq/novu.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/novuhq/novu/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/novuhq/novu.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/novuhq/novu/network/) [![GitHub issues](https://img.shields.io/github/issues/novuhq/novu.svg)](https://GitHub.com/Nnovuhq/novu/issues/)

[![GitHub license](https://img.shields.io/github/license/novuhq/novu.svg)](https://github.com/novuhq/novu/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/novuhq/novu.svg)](https://GitHub.com/novuhq/novu/graphs/contributors/) 

**Category**: Communication

**Github**: [novuhq/novu](https://github.com/novuhq/novu)

**Website**: [novu.co](https://novu.co/)

**Description**:
Components and APIs for email, sms, direct and push

**Alternative to**: [Courier](https://www.courier.com/), [MagicBell](https://www.magicbell.com/), [Knock](https://knock.app/)
