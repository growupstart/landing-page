
# FormKit 

<a href="https://formkit.com/"><img src="https://icons.duckduckgo.com/ip3/formkit.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/formkit/formkit.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/formkit/formkit/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/formkit/formkit.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/formkit/formkit/network/) [![GitHub issues](https://img.shields.io/github/issues/formkit/formkit.svg)](https://GitHub.com/Nformkit/formkit/issues/)

[![GitHub license](https://img.shields.io/github/license/formkit/formkit.svg)](https://github.com/formkit/formkit/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/formkit/formkit.svg)](https://GitHub.com/formkit/formkit/graphs/contributors/) 

**Category**: Form Building

**Github**: [formkit/formkit](https://github.com/formkit/formkit)

**Website**: [formkit.com](https://formkit.com/)

**Description**:
 A software to help build attractive forms

**Alternative to**: [Vueform](https://vueform.com/), [Typeform](https://www.typeform.com/)
