
# Glimesh 

<a href="https://glimesh.tv/"><img src="https://icons.duckduckgo.com/ip3/glimesh.tv.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/glimesh/glimesh.tv.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/glimesh/glimesh.tv/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/glimesh/glimesh.tv.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/glimesh/glimesh.tv/network/) [![GitHub issues](https://img.shields.io/github/issues/glimesh/glimesh.tv.svg)](https://GitHub.com/Nglimesh/glimesh.tv/issues/)

[![GitHub license](https://img.shields.io/github/license/glimesh/glimesh.tv.svg)](https://github.com/glimesh/glimesh.tv/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/glimesh/glimesh.tv.svg)](https://GitHub.com/glimesh/glimesh.tv/graphs/contributors/) 

**Category**: Streaming

**Github**: [glimesh/glimesh.tv](https://github.com/glimesh/glimesh.tv)

**Website**: [glimesh.tv](https://glimesh.tv/)

**Description**:
Live streaming platform

**Alternative to**: [Twitch](https://www.twitch.tv/)
