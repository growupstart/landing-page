
# Oso 

<a href="https://www.osohq.com/"><img src="https://icons.duckduckgo.com/ip3/www.osohq.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/osohq/oso.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/osohq/oso/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/osohq/oso.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/osohq/oso/network/) [![GitHub issues](https://img.shields.io/github/issues/osohq/oso.svg)](https://GitHub.com/Nosohq/oso/issues/)

[![GitHub license](https://img.shields.io/github/license/osohq/oso.svg)](https://github.com/osohq/oso/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/osohq/oso.svg)](https://GitHub.com/osohq/oso/graphs/contributors/) 

**Category**: Auth & SSO

**Github**: [osohq/oso](https://github.com/osohq/oso)

**Website**: [www.osohq.com](https://www.osohq.com/)

**Description**:
Authorization building framework

**Alternative to**: [Okta](https://okta.com/), [Auth0](https://auth0.com/)
