
# Hanko 

<a href="https://www.hanko.io"><img src="https://icons.duckduckgo.com/ip3/www.hanko.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/teamhanko/hanko.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/teamhanko/hanko/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/teamhanko/hanko.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/teamhanko/hanko/network/) [![GitHub issues](https://img.shields.io/github/issues/teamhanko/hanko.svg)](https://GitHub.com/Nteamhanko/hanko/issues/)

[![GitHub license](https://img.shields.io/github/license/teamhanko/hanko.svg)](https://github.com/teamhanko/hanko/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/teamhanko/hanko.svg)](https://GitHub.com/teamhanko/hanko/graphs/contributors/) 

**Category**: Auth & SSO

**Github**: [teamhanko/hanko](https://github.com/teamhanko/hanko)

**Website**: [www.hanko.io](https://www.hanko.io)

**Description**:
Passkey-first authentication framework

**Alternative to**: [Okta](https://okta.com/), [Auth0](https://auth0.com/)
