
# Ory 

<a href="https://www.ory.sh/"><img src="https://icons.duckduckgo.com/ip3/www.ory.sh.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/ory/kratos.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/ory/kratos/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/ory/kratos.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/ory/kratos/network/) [![GitHub issues](https://img.shields.io/github/issues/ory/kratos.svg)](https://GitHub.com/Nory/kratos/issues/)

[![GitHub license](https://img.shields.io/github/license/ory/kratos.svg)](https://github.com/ory/kratos/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/ory/kratos.svg)](https://GitHub.com/ory/kratos/graphs/contributors/) 

**Category**: Auth & SSO

**Github**: [ory/kratos](https://github.com/ory/kratos)

**Website**: [www.ory.sh](https://www.ory.sh/)

**Description**:
Identity platform

**Alternative to**: [Okta](https://okta.com/), [Auth0](https://auth0.com/)
