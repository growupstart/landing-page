
# Cerbos 

<a href="https://cerbos.dev/"><img src="https://icons.duckduckgo.com/ip3/cerbos.dev.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/cerbos/cerbos.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/cerbos/cerbos/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/cerbos/cerbos.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/cerbos/cerbos/network/) [![GitHub issues](https://img.shields.io/github/issues/cerbos/cerbos.svg)](https://GitHub.com/Ncerbos/cerbos/issues/)

[![GitHub license](https://img.shields.io/github/license/cerbos/cerbos.svg)](https://github.com/cerbos/cerbos/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/cerbos/cerbos.svg)](https://GitHub.com/cerbos/cerbos/graphs/contributors/) 

**Category**: Auth & SSO

**Github**: [cerbos/cerbos](https://github.com/cerbos/cerbos)

**Website**: [cerbos.dev](https://cerbos.dev/)

**Description**:
Granular access control

**Alternative to**: [Okta](https://okta.com/), [Auth0](https://auth0.com/)
