
# BoxyHQ 

<a href="https://boxyhq.com"><img src="https://icons.duckduckgo.com/ip3/boxyhq.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/boxyhq/jackson.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/boxyhq/jackson/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/boxyhq/jackson.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/boxyhq/jackson/network/) [![GitHub issues](https://img.shields.io/github/issues/boxyhq/jackson.svg)](https://GitHub.com/Nboxyhq/jackson/issues/)

[![GitHub license](https://img.shields.io/github/license/boxyhq/jackson.svg)](https://github.com/boxyhq/jackson/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/boxyhq/jackson.svg)](https://GitHub.com/boxyhq/jackson/graphs/contributors/) 

**Category**: Auth & SSO

**Github**: [boxyhq/jackson](https://github.com/boxyhq/jackson)

**Website**: [boxyhq.com](https://boxyhq.com)

**Description**:
Enterprise Readiness made simple

**Alternative to**: [Auth0](https://auth0.com/)
