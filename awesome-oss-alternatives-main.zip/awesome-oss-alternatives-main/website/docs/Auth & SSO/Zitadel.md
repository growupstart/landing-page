
# Zitadel 

<a href="https://zitadel.com/"><img src="https://icons.duckduckgo.com/ip3/zitadel.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/zitadel/zitadel.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/zitadel/zitadel/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/zitadel/zitadel.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/zitadel/zitadel/network/) [![GitHub issues](https://img.shields.io/github/issues/zitadel/zitadel.svg)](https://GitHub.com/Nzitadel/zitadel/issues/)

[![GitHub license](https://img.shields.io/github/license/zitadel/zitadel.svg)](https://github.com/zitadel/zitadel/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/zitadel/zitadel.svg)](https://GitHub.com/zitadel/zitadel/graphs/contributors/) 

**Category**: Auth & SSO

**Github**: [zitadel/zitadel](https://github.com/zitadel/zitadel)

**Website**: [zitadel.com](https://zitadel.com/)

**Description**:
User authentication and session management framework

**Alternative to**: [Okta](https://okta.com/), [Auth0](https://auth0.com/)
