
# Filestash 

<a href="https://www.filestash.app/"><img src="https://icons.duckduckgo.com/ip3/www.filestash.app.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/mickael-kerjean/filestash.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/mickael-kerjean/filestash/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/mickael-kerjean/filestash.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/mickael-kerjean/filestash/network/) [![GitHub issues](https://img.shields.io/github/issues/mickael-kerjean/filestash.svg)](https://GitHub.com/Nmickael-kerjean/filestash/issues/)

[![GitHub license](https://img.shields.io/github/license/mickael-kerjean/filestash.svg)](https://github.com/mickael-kerjean/filestash/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/mickael-kerjean/filestash.svg)](https://GitHub.com/mickael-kerjean/filestash/graphs/contributors/) 

**Category**: File Hosting

**Github**: [mickael-kerjean/filestash](https://github.com/mickael-kerjean/filestash)

**Website**: [www.filestash.app](https://www.filestash.app/)

**Description**:
A file manager that let you manage your data anywhere it is located

**Alternative to**: [Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)
