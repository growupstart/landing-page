
# Nextcloud 

<a href="https://nextcloud.com/"><img src="https://icons.duckduckgo.com/ip3/nextcloud.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/nextcloud/server.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/nextcloud/server/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/nextcloud/server.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/nextcloud/server/network/) [![GitHub issues](https://img.shields.io/github/issues/nextcloud/server.svg)](https://GitHub.com/Nnextcloud/server/issues/)

[![GitHub license](https://img.shields.io/github/license/nextcloud/server.svg)](https://github.com/nextcloud/server/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/nextcloud/server.svg)](https://GitHub.com/nextcloud/server/graphs/contributors/) 

**Category**: File Hosting

**Github**: [nextcloud/server](https://github.com/nextcloud/server)

**Website**: [nextcloud.com](https://nextcloud.com/)

**Description**:
A personal cloud which runs on your own server

**Alternative to**: [Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)
