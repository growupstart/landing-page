
# Owncloud 

<a href="https://owncloud.com/"><img src="https://icons.duckduckgo.com/ip3/owncloud.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/owncloud/core.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/owncloud/core/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/owncloud/core.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/owncloud/core/network/) [![GitHub issues](https://img.shields.io/github/issues/owncloud/core.svg)](https://GitHub.com/Nowncloud/core/issues/)

[![GitHub license](https://img.shields.io/github/license/owncloud/core.svg)](https://github.com/owncloud/core/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/owncloud/core.svg)](https://GitHub.com/owncloud/core/graphs/contributors/) 

**Category**: File Hosting

**Github**: [owncloud/core](https://github.com/owncloud/core)

**Website**: [owncloud.com](https://owncloud.com/)

**Description**:
A personal cloud which runs on your own server

**Alternative to**: [Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)
