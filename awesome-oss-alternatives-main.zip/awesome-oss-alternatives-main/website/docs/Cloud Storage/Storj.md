
# Storj 

<a href="https://www.storj.io/"><img src="https://icons.duckduckgo.com/ip3/www.storj.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/storj/storj.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/storj/storj/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/storj/storj.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/storj/storj/network/) [![GitHub issues](https://img.shields.io/github/issues/storj/storj.svg)](https://GitHub.com/Nstorj/storj/issues/)

[![GitHub license](https://img.shields.io/github/license/storj/storj.svg)](https://github.com/storj/storj/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/storj/storj.svg)](https://GitHub.com/storj/storj/graphs/contributors/) 

**Category**: Cloud Storage

**Github**: [storj/storj](https://github.com/storj/storj)

**Website**: [www.storj.io](https://www.storj.io/)

**Description**:
Decentralized cloud storage

**Alternative to**: [Amazon S3](https://aws.amazon.com/s3/)
