
# Trilium.cc 

<a href="https://trilium.cc/"><img src="https://icons.duckduckgo.com/ip3/trilium.cc.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/zadam/trilium.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/zadam/trilium/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/zadam/trilium.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/zadam/trilium/network/) [![GitHub issues](https://img.shields.io/github/issues/zadam/trilium.svg)](https://GitHub.com/Nzadam/trilium/issues/)

[![GitHub license](https://img.shields.io/github/license/zadam/trilium.svg)](https://github.com/zadam/trilium/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/zadam/trilium.svg)](https://GitHub.com/zadam/trilium/graphs/contributors/) 

**Category**: Notetaking

**Github**: [zadam/trilium](https://github.com/zadam/trilium)

**Website**: [trilium.cc](https://trilium.cc/)

**Description**:
Personal knowledge base

**Alternative to**: [Evernote](https://evernote.com/), [Onenote](https://www.onenote.com/)
