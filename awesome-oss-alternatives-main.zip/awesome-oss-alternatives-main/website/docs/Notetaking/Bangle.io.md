
# Bangle.io 

<a href="https://bangle.io/"><img src="https://icons.duckduckgo.com/ip3/bangle.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/bangle-io/bangle-io.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/bangle-io/bangle-io/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/bangle-io/bangle-io.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/bangle-io/bangle-io/network/) [![GitHub issues](https://img.shields.io/github/issues/bangle-io/bangle-io.svg)](https://GitHub.com/Nbangle-io/bangle-io/issues/)

[![GitHub license](https://img.shields.io/github/license/bangle-io/bangle-io.svg)](https://github.com/bangle-io/bangle-io/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/bangle-io/bangle-io.svg)](https://GitHub.com/bangle-io/bangle-io/graphs/contributors/) 

**Category**: Notetaking

**Github**: [bangle-io/bangle-io](https://github.com/bangle-io/bangle-io)

**Website**: [bangle.io](https://bangle.io/)

**Description**:
A rich note note taking web app that works on top of your locally saved Markdown files

**Alternative to**: [Notion](https://www.notion.so/)
