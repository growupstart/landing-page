
# Outline 

<a href="https://www.getoutline.com/"><img src="https://icons.duckduckgo.com/ip3/www.getoutline.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/outline/outline.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/outline/outline/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/outline/outline.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/outline/outline/network/) [![GitHub issues](https://img.shields.io/github/issues/outline/outline.svg)](https://GitHub.com/Noutline/outline/issues/)

[![GitHub license](https://img.shields.io/github/license/outline/outline.svg)](https://github.com/outline/outline/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/outline/outline.svg)](https://GitHub.com/outline/outline/graphs/contributors/) 

**Category**: Notetaking

**Github**: [outline/outline](https://github.com/outline/outline)

**Website**: [www.getoutline.com](https://www.getoutline.com/)

**Description**:
Wiki and knowledge base

**Alternative to**: [Notion](https://notion.so)
