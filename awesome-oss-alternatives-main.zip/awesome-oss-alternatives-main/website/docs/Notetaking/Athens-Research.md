
# Athens Research 

<a href="https://www.athensresearch.org/"><img src="https://icons.duckduckgo.com/ip3/www.athensresearch.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/athensresearch/athens.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/athensresearch/athens/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/athensresearch/athens.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/athensresearch/athens/network/) [![GitHub issues](https://img.shields.io/github/issues/athensresearch/athens.svg)](https://GitHub.com/Nathensresearch/athens/issues/)

[![GitHub license](https://img.shields.io/github/license/athensresearch/athens.svg)](https://github.com/athensresearch/athens/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/athensresearch/athens.svg)](https://GitHub.com/athensresearch/athens/graphs/contributors/) 

**Category**: Notetaking

**Github**: [athensresearch/athens](https://github.com/athensresearch/athens)

**Website**: [www.athensresearch.org](https://www.athensresearch.org/)

**Description**:
Knowledge graph for research and notetaking

**Alternative to**: [Roam Research](https://roamresearch.com/)
