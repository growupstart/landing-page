
# AppFlowy 

<a href="https://www.appflowy.io/"><img src="https://icons.duckduckgo.com/ip3/www.appflowy.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/AppFlowy-IO/appflowy.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/AppFlowy-IO/appflowy/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/AppFlowy-IO/appflowy.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/AppFlowy-IO/appflowy/network/) [![GitHub issues](https://img.shields.io/github/issues/AppFlowy-IO/appflowy.svg)](https://GitHub.com/NAppFlowy-IO/appflowy/issues/)

[![GitHub license](https://img.shields.io/github/license/AppFlowy-IO/appflowy.svg)](https://github.com/AppFlowy-IO/appflowy/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/AppFlowy-IO/appflowy.svg)](https://GitHub.com/AppFlowy-IO/appflowy/graphs/contributors/) 

**Category**: Notetaking

**Github**: [AppFlowy-IO/appflowy](https://github.com/AppFlowy-IO/appflowy)

**Website**: [www.appflowy.io](https://www.appflowy.io/)

**Description**:
Open-source alternative to Notion

**Alternative to**: [Notion](https://www.notion.so/)
