
# Dendron 

<a href="https://www.dendron.so/"><img src="https://icons.duckduckgo.com/ip3/www.dendron.so.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/dendronhq/dendron.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/dendronhq/dendron/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/dendronhq/dendron.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/dendronhq/dendron/network/) [![GitHub issues](https://img.shields.io/github/issues/dendronhq/dendron.svg)](https://GitHub.com/Ndendronhq/dendron/issues/)

[![GitHub license](https://img.shields.io/github/license/dendronhq/dendron.svg)](https://github.com/dendronhq/dendron/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/dendronhq/dendron.svg)](https://GitHub.com/dendronhq/dendron/graphs/contributors/) 

**Category**: Notetaking

**Github**: [dendronhq/dendron](https://github.com/dendronhq/dendron)

**Website**: [www.dendron.so](https://www.dendron.so/)

**Description**:
Knowledge base plugin for VS Code

**Alternative to**: [Roam Research](https://roamresearch.com/)
