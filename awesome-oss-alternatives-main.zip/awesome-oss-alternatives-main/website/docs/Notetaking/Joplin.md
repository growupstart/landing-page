
# Joplin 

<a href="https://joplinapp.org/"><img src="https://icons.duckduckgo.com/ip3/joplinapp.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/laurent22/joplin.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/laurent22/joplin/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/laurent22/joplin.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/laurent22/joplin/network/) [![GitHub issues](https://img.shields.io/github/issues/laurent22/joplin.svg)](https://GitHub.com/Nlaurent22/joplin/issues/)

[![GitHub license](https://img.shields.io/github/license/laurent22/joplin.svg)](https://github.com/laurent22/joplin/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/laurent22/joplin.svg)](https://GitHub.com/laurent22/joplin/graphs/contributors/) 

**Category**: Notetaking

**Github**: [laurent22/joplin](https://github.com/laurent22/joplin)

**Website**: [joplinapp.org](https://joplinapp.org/)

**Description**:
Secure, Cross-platform, Open-Source  Markdown Note Taking App

**Alternative to**: [Evernote](https://evernote.com/), [Onenote](hhttps://www.onenote.com/n), [Roam Research](https://roamresearch.com/)
