
# Logseq 

<a href="https://logseq.com/"><img src="https://icons.duckduckgo.com/ip3/logseq.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/logseq/logseq.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/logseq/logseq/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/logseq/logseq.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/logseq/logseq/network/) [![GitHub issues](https://img.shields.io/github/issues/logseq/logseq.svg)](https://GitHub.com/Nlogseq/logseq/issues/)

[![GitHub license](https://img.shields.io/github/license/logseq/logseq.svg)](https://github.com/logseq/logseq/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/logseq/logseq.svg)](https://GitHub.com/logseq/logseq/graphs/contributors/) 

**Category**: Notetaking

**Github**: [logseq/logseq](https://github.com/logseq/logseq)

**Website**: [logseq.com](https://logseq.com/)

**Description**:
Knowledge base manager

**Alternative to**: [Roam Research](https://roamresearch.com/)
