
# Notabase 

<a href="https://notabase.io"><img src="https://icons.duckduckgo.com/ip3/notabase.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/churichard/notabase.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/churichard/notabase/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/churichard/notabase.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/churichard/notabase/network/) [![GitHub issues](https://img.shields.io/github/issues/churichard/notabase.svg)](https://GitHub.com/Nchurichard/notabase/issues/)

[![GitHub license](https://img.shields.io/github/license/churichard/notabase.svg)](https://github.com/churichard/notabase/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/churichard/notabase.svg)](https://GitHub.com/churichard/notabase/graphs/contributors/) 

**Category**: Notetaking

**Github**: [churichard/notabase](https://github.com/churichard/notabase)

**Website**: [notabase.io](https://notabase.io)

**Description**:
Powerful and easy-to-use note-taking app for networked thinking

**Alternative to**: [Notion](https://www.notion.so/), [Roam Research](https://roamresearch.com/)
