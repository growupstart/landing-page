
# Boost Note 

<a href="https://boostnote.io/"><img src="https://icons.duckduckgo.com/ip3/boostnote.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/BoostIO/BoostNote-App.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/BoostIO/BoostNote-App/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/BoostIO/BoostNote-App.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/BoostIO/BoostNote-App/network/) [![GitHub issues](https://img.shields.io/github/issues/BoostIO/BoostNote-App.svg)](https://GitHub.com/NBoostIO/BoostNote-App/issues/)

[![GitHub license](https://img.shields.io/github/license/BoostIO/BoostNote-App.svg)](https://github.com/BoostIO/BoostNote-App/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/BoostIO/BoostNote-App.svg)](https://GitHub.com/BoostIO/BoostNote-App/graphs/contributors/) 

**Category**: Notetaking

**Github**: [BoostIO/BoostNote-App](https://github.com/BoostIO/BoostNote-App)

**Website**: [boostnote.io](https://boostnote.io/)

**Description**:
Collaborative workspace for developer teams

**Alternative to**: [Notion](https://www.notion.so/)
