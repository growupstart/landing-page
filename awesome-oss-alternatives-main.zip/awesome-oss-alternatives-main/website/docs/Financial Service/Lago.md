
# Lago 

<a href="https://www.getlago.com/"><img src="https://icons.duckduckgo.com/ip3/www.getlago.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/getlago/lago.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/getlago/lago/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/getlago/lago.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/getlago/lago/network/) [![GitHub issues](https://img.shields.io/github/issues/getlago/lago.svg)](https://GitHub.com/Ngetlago/lago/issues/)

[![GitHub license](https://img.shields.io/github/license/getlago/lago.svg)](https://github.com/getlago/lago/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/getlago/lago.svg)](https://GitHub.com/getlago/lago/graphs/contributors/) 

**Category**: Financial Service

**Github**: [getlago/lago](https://github.com/getlago/lago)

**Website**: [www.getlago.com](https://www.getlago.com/)

**Description**:
Open Source Billing API

**Alternative to**: [Stripe Billing](https://stripe.com/billing), [Chargebee](https://www.chargebee.com/)
