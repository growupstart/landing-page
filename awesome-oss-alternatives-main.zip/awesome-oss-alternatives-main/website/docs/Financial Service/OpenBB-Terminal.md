
# OpenBB Terminal 

<a href="https://github.com/openbb-finance/OpenBBTerminal"><img src="https://icons.duckduckgo.com/ip3/github.com/openbb-finance/OpenBBTerminal.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/GamestonkTerminal/GamestonkTerminal.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/GamestonkTerminal/GamestonkTerminal/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/GamestonkTerminal/GamestonkTerminal.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/GamestonkTerminal/GamestonkTerminal/network/) [![GitHub issues](https://img.shields.io/github/issues/GamestonkTerminal/GamestonkTerminal.svg)](https://GitHub.com/NGamestonkTerminal/GamestonkTerminal/issues/)

[![GitHub license](https://img.shields.io/github/license/GamestonkTerminal/GamestonkTerminal.svg)](https://github.com/GamestonkTerminal/GamestonkTerminal/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/GamestonkTerminal/GamestonkTerminal.svg)](https://GitHub.com/GamestonkTerminal/GamestonkTerminal/graphs/contributors/) 

**Category**: Financial Service

**Github**: [GamestonkTerminal/GamestonkTerminal](https://github.com/GamestonkTerminal/GamestonkTerminal)

**Website**: [github.com/openbb-finance/OpenBBTerminal](https://github.com/openbb-finance/OpenBBTerminal)

**Description**:
Investment research for everyone

**Alternative to**: [Bloomberg](https://www.bloomberg.com/)
