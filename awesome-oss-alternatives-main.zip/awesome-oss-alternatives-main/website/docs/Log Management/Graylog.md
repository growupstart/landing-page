
# Graylog 

<a href="https://www.graylog.org/"><img src="https://icons.duckduckgo.com/ip3/www.graylog.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Graylog2/graylog2-server.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Graylog2/graylog2-server/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Graylog2/graylog2-server.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Graylog2/graylog2-server/network/) [![GitHub issues](https://img.shields.io/github/issues/Graylog2/graylog2-server.svg)](https://GitHub.com/NGraylog2/graylog2-server/issues/)

[![GitHub license](https://img.shields.io/github/license/Graylog2/graylog2-server.svg)](https://github.com/Graylog2/graylog2-server/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Graylog2/graylog2-server.svg)](https://GitHub.com/Graylog2/graylog2-server/graphs/contributors/) 

**Category**: Log Management

**Github**: [Graylog2/graylog2-server](https://github.com/Graylog2/graylog2-server)

**Website**: [www.graylog.org](https://www.graylog.org/)

**Description**:
Log management platform

**Alternative to**: [Splunk](https://www.splunk.com/)
