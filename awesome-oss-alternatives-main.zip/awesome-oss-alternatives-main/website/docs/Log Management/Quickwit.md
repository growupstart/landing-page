
# Quickwit 

<a href="https://quickwit.io/"><img src="https://icons.duckduckgo.com/ip3/quickwit.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/quickwit-oss/quickwit.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/quickwit-oss/quickwit/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/quickwit-oss/quickwit.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/quickwit-oss/quickwit/network/) [![GitHub issues](https://img.shields.io/github/issues/quickwit-oss/quickwit.svg)](https://GitHub.com/Nquickwit-oss/quickwit/issues/)

[![GitHub license](https://img.shields.io/github/license/quickwit-oss/quickwit.svg)](https://github.com/quickwit-oss/quickwit/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/quickwit-oss/quickwit.svg)](https://GitHub.com/quickwit-oss/quickwit/graphs/contributors/) 

**Category**: Log Management

**Github**: [quickwit-oss/quickwit](https://github.com/quickwit-oss/quickwit)

**Website**: [quickwit.io](https://quickwit.io/)

**Description**:
Cloud-native log management & analytics

**Alternative to**: [Elastic Cloud](https://www.elastic.co/elastic-stack/)
