
# Jina.ai 

<a href="https://jina.ai/"><img src="https://icons.duckduckgo.com/ip3/jina.ai.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/jina-ai/jina.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/jina-ai/jina/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/jina-ai/jina.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/jina-ai/jina/network/) [![GitHub issues](https://img.shields.io/github/issues/jina-ai/jina.svg)](https://GitHub.com/Njina-ai/jina/issues/)

[![GitHub license](https://img.shields.io/github/license/jina-ai/jina.svg)](https://github.com/jina-ai/jina/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/jina-ai/jina.svg)](https://GitHub.com/jina-ai/jina/graphs/contributors/) 

**Category**: Enterprise Search

**Github**: [jina-ai/jina](https://github.com/jina-ai/jina)

**Website**: [jina.ai](https://jina.ai/)

**Description**:
Neural search framework for 𝙖𝙣𝙮 kind of data (including images)

**Alternative to**: [Algolia](https://www.algolia.com/)
