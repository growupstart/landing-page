
# Meilisearch 

<a href="https://www.meilisearch.com/"><img src="https://icons.duckduckgo.com/ip3/www.meilisearch.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/meilisearch/meilisearch.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/meilisearch/meilisearch/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/meilisearch/meilisearch.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/meilisearch/meilisearch/network/) [![GitHub issues](https://img.shields.io/github/issues/meilisearch/meilisearch.svg)](https://GitHub.com/Nmeilisearch/meilisearch/issues/)

[![GitHub license](https://img.shields.io/github/license/meilisearch/meilisearch.svg)](https://github.com/meilisearch/meilisearch/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/meilisearch/meilisearch.svg)](https://GitHub.com/meilisearch/meilisearch/graphs/contributors/) 

**Category**: Enterprise Search

**Github**: [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch)

**Website**: [www.meilisearch.com](https://www.meilisearch.com/)

**Description**:
Typo tolerant search engine

**Alternative to**: [Algolia](https://www.algolia.com/)
