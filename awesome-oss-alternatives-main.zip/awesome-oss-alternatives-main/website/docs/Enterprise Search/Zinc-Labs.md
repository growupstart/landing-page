
# Zinc Labs 

<a href="https://www.zinclabs.io)'s [Zin"><img src="https://icons.duckduckgo.com/ip3/www.zinclabs.io)'s [Zin.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/prabhatsharma/zinc.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/prabhatsharma/zinc/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/prabhatsharma/zinc.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/prabhatsharma/zinc/network/) [![GitHub issues](https://img.shields.io/github/issues/prabhatsharma/zinc.svg)](https://GitHub.com/Nprabhatsharma/zinc/issues/)

[![GitHub license](https://img.shields.io/github/license/prabhatsharma/zinc.svg)](https://github.com/prabhatsharma/zinc/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/prabhatsharma/zinc.svg)](https://GitHub.com/prabhatsharma/zinc/graphs/contributors/) 

**Category**: Enterprise Search

**Github**: [prabhatsharma/zinc](https://github.com/prabhatsharma/zinc)

**Website**: [www.zinclabs.io)'s [Zin](https://www.zinclabs.io)'s [Zin)

**Description**:
Cloud native full text search

**Alternative to**: [Elastic Cloud](https://www.elastic.co/elastic-stack/)
