
# AppBase 

<a href="https://www.appbase.io/"><img src="https://icons.duckduckgo.com/ip3/www.appbase.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/appbaseio/reactivesearch.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/appbaseio/reactivesearch/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/appbaseio/reactivesearch.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/appbaseio/reactivesearch/network/) [![GitHub issues](https://img.shields.io/github/issues/appbaseio/reactivesearch.svg)](https://GitHub.com/Nappbaseio/reactivesearch/issues/)

[![GitHub license](https://img.shields.io/github/license/appbaseio/reactivesearch.svg)](https://github.com/appbaseio/reactivesearch/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/appbaseio/reactivesearch.svg)](https://GitHub.com/appbaseio/reactivesearch/graphs/contributors/) 

**Category**: Enterprise Search

**Github**: [appbaseio/reactivesearch](https://github.com/appbaseio/reactivesearch)

**Website**: [www.appbase.io](https://www.appbase.io/)

**Description**:
Search UI components for React and Vue

**Alternative to**: [Algolia](https://www.algolia.com/)
