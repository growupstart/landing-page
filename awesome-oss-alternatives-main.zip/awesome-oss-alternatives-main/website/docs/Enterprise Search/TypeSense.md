
# TypeSense 

<a href="https://typesense.org/"><img src="https://icons.duckduckgo.com/ip3/typesense.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/typesense/typesense.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/typesense/typesense/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/typesense/typesense.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/typesense/typesense/network/) [![GitHub issues](https://img.shields.io/github/issues/typesense/typesense.svg)](https://GitHub.com/Ntypesense/typesense/issues/)

[![GitHub license](https://img.shields.io/github/license/typesense/typesense.svg)](https://github.com/typesense/typesense/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/typesense/typesense.svg)](https://GitHub.com/typesense/typesense/graphs/contributors/) 

**Category**: Enterprise Search

**Github**: [typesense/typesense](https://github.com/typesense/typesense)

**Website**: [typesense.org](https://typesense.org/)

**Description**:
Typo tolerant fuzzy search engine

**Alternative to**: [Algolia](https://www.algolia.com/)
