
# SeMI 

<a href="https://www.semi.technology/)'s [Weaviat"><img src="https://icons.duckduckgo.com/ip3/www.semi.technology/)'s [Weaviat.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/semi-technologies/weaviate.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/semi-technologies/weaviate/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/semi-technologies/weaviate.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/semi-technologies/weaviate/network/) [![GitHub issues](https://img.shields.io/github/issues/semi-technologies/weaviate.svg)](https://GitHub.com/Nsemi-technologies/weaviate/issues/)

[![GitHub license](https://img.shields.io/github/license/semi-technologies/weaviate.svg)](https://github.com/semi-technologies/weaviate/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/semi-technologies/weaviate.svg)](https://GitHub.com/semi-technologies/weaviate/graphs/contributors/) 

**Category**: Enterprise Search

**Github**: [semi-technologies/weaviate](https://github.com/semi-technologies/weaviate)

**Website**: [www.semi.technology/)'s [Weaviat](https://www.semi.technology/)'s [Weaviat)

**Description**:
Real-time vector search engine

**Alternative to**: [Google Vertex AI](https://cloud.google.com/vertex-ai), [Algolia](https://www.algolia.com/)
