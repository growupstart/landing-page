
# Cal.com 

<a href="https://cal.com/"><img src="https://icons.duckduckgo.com/ip3/cal.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/calendso/calendso.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/calendso/calendso/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/calendso/calendso.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/calendso/calendso/network/) [![GitHub issues](https://img.shields.io/github/issues/calendso/calendso.svg)](https://GitHub.com/Ncalendso/calendso/issues/)

[![GitHub license](https://img.shields.io/github/license/calendso/calendso.svg)](https://github.com/calendso/calendso/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/calendso/calendso.svg)](https://GitHub.com/calendso/calendso/graphs/contributors/) 

**Category**: Scheduling

**Github**: [calendso/calendso](https://github.com/calendso/calendso)

**Website**: [cal.com](https://cal.com/)

**Description**:
Scheduling infrastructure, alternative to Calendly

**Alternative to**: [Calendly](https://calendly.com/)
