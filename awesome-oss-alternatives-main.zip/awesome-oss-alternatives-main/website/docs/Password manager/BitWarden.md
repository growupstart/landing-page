
# BitWarden 

<a href="https://bitwarden.com/"><img src="https://icons.duckduckgo.com/ip3/bitwarden.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/bitwarden/server.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/bitwarden/server/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/bitwarden/server.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/bitwarden/server/network/) [![GitHub issues](https://img.shields.io/github/issues/bitwarden/server.svg)](https://GitHub.com/Nbitwarden/server/issues/)

[![GitHub license](https://img.shields.io/github/license/bitwarden/server.svg)](https://github.com/bitwarden/server/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/bitwarden/server.svg)](https://GitHub.com/bitwarden/server/graphs/contributors/) 

**Category**: Password manager

**Github**: [bitwarden/server](https://github.com/bitwarden/server)

**Website**: [bitwarden.com](https://bitwarden.com/)

**Description**:
Password manager for teams and individuals

**Alternative to**: [1Password](https://1password.com/)
