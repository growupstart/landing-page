
# Passbolt 

<a href="https://www.passbolt.com/"><img src="https://icons.duckduckgo.com/ip3/www.passbolt.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/passbolt/passbolt_api.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/passbolt/passbolt_api/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/passbolt/passbolt_api.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/passbolt/passbolt_api/network/) [![GitHub issues](https://img.shields.io/github/issues/passbolt/passbolt_api.svg)](https://GitHub.com/Npassbolt/passbolt_api/issues/)

[![GitHub license](https://img.shields.io/github/license/passbolt/passbolt_api.svg)](https://github.com/passbolt/passbolt_api/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/passbolt/passbolt_api.svg)](https://GitHub.com/passbolt/passbolt_api/graphs/contributors/) 

**Category**: Password manager

**Github**: [passbolt/passbolt_api](https://github.com/passbolt/passbolt_api)

**Website**: [www.passbolt.com](https://www.passbolt.com/)

**Description**:
Password manager for teams and individuals

**Alternative to**: [1Password](https://1password.com/)
