
# Padloc 

<a href="https://padloc.app/"><img src="https://icons.duckduckgo.com/ip3/padloc.app.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/padloc/padloc.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/padloc/padloc/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/padloc/padloc.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/padloc/padloc/network/) [![GitHub issues](https://img.shields.io/github/issues/padloc/padloc.svg)](https://GitHub.com/Npadloc/padloc/issues/)

[![GitHub license](https://img.shields.io/github/license/padloc/padloc.svg)](https://github.com/padloc/padloc/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/padloc/padloc.svg)](https://GitHub.com/padloc/padloc/graphs/contributors/) 

**Category**: Password manager

**Github**: [padloc/padloc](https://github.com/padloc/padloc)

**Website**: [padloc.app](https://padloc.app/)

**Description**:
Password manager for teams and individuals

**Alternative to**: [1Password](https://1password.com/)
