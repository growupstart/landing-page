
# Pipedream 

<a href="https://pipedream.com/"><img src="https://icons.duckduckgo.com/ip3/pipedream.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/PipedreamHQ/pipedream.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/PipedreamHQ/pipedream/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/PipedreamHQ/pipedream.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/PipedreamHQ/pipedream/network/) [![GitHub issues](https://img.shields.io/github/issues/PipedreamHQ/pipedream.svg)](https://GitHub.com/NPipedreamHQ/pipedream/issues/)

[![GitHub license](https://img.shields.io/github/license/PipedreamHQ/pipedream.svg)](https://github.com/PipedreamHQ/pipedream/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/PipedreamHQ/pipedream.svg)](https://GitHub.com/PipedreamHQ/pipedream/graphs/contributors/) 

**Category**: Workflow automation

**Github**: [PipedreamHQ/pipedream](https://github.com/PipedreamHQ/pipedream)

**Website**: [pipedream.com](https://pipedream.com/)

**Description**:
Workflow automation and API integration platform

**Alternative to**: [Zapier](https://zapier.com/), [Integromat](https://www.integromat.com/)
