
# N8N 

<a href="https://n8n.io/"><img src="https://icons.duckduckgo.com/ip3/n8n.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/n8n-io/n8n.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/n8n-io/n8n/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/n8n-io/n8n.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/n8n-io/n8n/network/) [![GitHub issues](https://img.shields.io/github/issues/n8n-io/n8n.svg)](https://GitHub.com/Nn8n-io/n8n/issues/)

[![GitHub license](https://img.shields.io/github/license/n8n-io/n8n.svg)](https://github.com/n8n-io/n8n/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/n8n-io/n8n.svg)](https://GitHub.com/n8n-io/n8n/graphs/contributors/) 

**Category**: Workflow automation

**Github**: [n8n-io/n8n](https://github.com/n8n-io/n8n)

**Website**: [n8n.io](https://n8n.io/)

**Description**:
Node-based workflow automation tool for developers

**Alternative to**: [Zapier](https://zapier.com/)
