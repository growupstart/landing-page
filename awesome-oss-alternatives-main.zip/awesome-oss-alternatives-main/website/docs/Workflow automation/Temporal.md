
# Temporal 

<a href="https://temporal.io/"><img src="https://icons.duckduckgo.com/ip3/temporal.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/temporalio/temporal.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/temporalio/temporal/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/temporalio/temporal.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/temporalio/temporal/network/) [![GitHub issues](https://img.shields.io/github/issues/temporalio/temporal.svg)](https://GitHub.com/Ntemporalio/temporal/issues/)

[![GitHub license](https://img.shields.io/github/license/temporalio/temporal.svg)](https://github.com/temporalio/temporal/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/temporalio/temporal.svg)](https://GitHub.com/temporalio/temporal/graphs/contributors/) 

**Category**: Workflow automation

**Github**: [temporalio/temporal](https://github.com/temporalio/temporal)

**Website**: [temporal.io](https://temporal.io/)

**Description**:
Workflows as code platform

**Alternative to**: [Zapier](https://zapier.com/)
