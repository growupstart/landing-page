
# Swetrix 

<a href="https://swetrix.com"><img src="https://icons.duckduckgo.com/ip3/swetrix.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/swetrix/swetrix-js.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/swetrix/swetrix-js/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/swetrix/swetrix-js.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/swetrix/swetrix-js/network/) [![GitHub issues](https://img.shields.io/github/issues/swetrix/swetrix-js.svg)](https://GitHub.com/Nswetrix/swetrix-js/issues/)

[![GitHub license](https://img.shields.io/github/license/swetrix/swetrix-js.svg)](https://github.com/swetrix/swetrix-js/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/swetrix/swetrix-js.svg)](https://GitHub.com/swetrix/swetrix-js/graphs/contributors/) 

**Category**: Website analytics

**Github**: [swetrix/swetrix-js](https://github.com/swetrix/swetrix-js)

**Website**: [swetrix.com](https://swetrix.com)

**Description**:
Google Analytics alternative

**Alternative to**: [Google Analytics](https://analytics.google.com/)
