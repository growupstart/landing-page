
# Plausible 

<a href="https://plausible.io/"><img src="https://icons.duckduckgo.com/ip3/plausible.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/plausible/analytics.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/plausible/analytics/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/plausible/analytics.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/plausible/analytics/network/) [![GitHub issues](https://img.shields.io/github/issues/plausible/analytics.svg)](https://GitHub.com/Nplausible/analytics/issues/)

[![GitHub license](https://img.shields.io/github/license/plausible/analytics.svg)](https://github.com/plausible/analytics/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/plausible/analytics.svg)](https://GitHub.com/plausible/analytics/graphs/contributors/) 

**Category**: Website analytics

**Github**: [plausible/analytics](https://github.com/plausible/analytics)

**Website**: [plausible.io](https://plausible.io/)

**Description**:
Google Analytics alternative

**Alternative to**: [Google Analytics](https://analytics.google.com/)
