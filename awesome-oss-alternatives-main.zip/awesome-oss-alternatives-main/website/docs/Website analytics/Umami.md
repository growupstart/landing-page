
# Umami 

<a href="https://umami.is"><img src="https://icons.duckduckgo.com/ip3/umami.is.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/mikecao/umami.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/mikecao/umami/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/mikecao/umami.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/mikecao/umami/network/) [![GitHub issues](https://img.shields.io/github/issues/mikecao/umami.svg)](https://GitHub.com/Nmikecao/umami/issues/)

[![GitHub license](https://img.shields.io/github/license/mikecao/umami.svg)](https://github.com/mikecao/umami/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/mikecao/umami.svg)](https://GitHub.com/mikecao/umami/graphs/contributors/) 

**Category**: Website analytics

**Github**: [mikecao/umami](https://github.com/mikecao/umami)

**Website**: [umami.is](https://umami.is)

**Description**:
Google Analytics alternative

**Alternative to**: [Google Analytics](https://analytics.google.com/)
