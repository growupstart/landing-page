
# GoatCounter 

<a href="https://www.goatcounter.com/"><img src="https://icons.duckduckgo.com/ip3/www.goatcounter.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/arp242/goatcounter.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/arp242/goatcounter/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/arp242/goatcounter.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/arp242/goatcounter/network/) [![GitHub issues](https://img.shields.io/github/issues/arp242/goatcounter.svg)](https://GitHub.com/Narp242/goatcounter/issues/)

[![GitHub license](https://img.shields.io/github/license/arp242/goatcounter.svg)](https://github.com/arp242/goatcounter/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/arp242/goatcounter.svg)](https://GitHub.com/arp242/goatcounter/graphs/contributors/) 

**Category**: Website analytics

**Github**: [arp242/goatcounter](https://github.com/arp242/goatcounter)

**Website**: [www.goatcounter.com](https://www.goatcounter.com/)

**Description**:
Google Analytics alternative

**Alternative to**: [Google Analytics](https://analytics.google.com/)
