
# Matomo 

<a href="https://matomo.org/"><img src="https://icons.duckduckgo.com/ip3/matomo.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/matomo-org/matomo.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/matomo-org/matomo/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/matomo-org/matomo.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/matomo-org/matomo/network/) [![GitHub issues](https://img.shields.io/github/issues/matomo-org/matomo.svg)](https://GitHub.com/Nmatomo-org/matomo/issues/)

[![GitHub license](https://img.shields.io/github/license/matomo-org/matomo.svg)](https://github.com/matomo-org/matomo/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/matomo-org/matomo.svg)](https://GitHub.com/matomo-org/matomo/graphs/contributors/) 

**Category**: Website analytics

**Github**: [matomo-org/matomo](https://github.com/matomo-org/matomo)

**Website**: [matomo.org](https://matomo.org/)

**Description**:
Google Analytics alternative

**Alternative to**: [Google Analytics](https://analytics.google.com/)
