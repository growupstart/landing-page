
# Shuup 

<a href="https://shuup.com"><img src="https://icons.duckduckgo.com/ip3/shuup.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/shuup/shuup.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/shuup/shuup/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/shuup/shuup.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/shuup/shuup/network/) [![GitHub issues](https://img.shields.io/github/issues/shuup/shuup.svg)](https://GitHub.com/Nshuup/shuup/issues/)

[![GitHub license](https://img.shields.io/github/license/shuup/shuup.svg)](https://github.com/shuup/shuup/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/shuup/shuup.svg)](https://GitHub.com/shuup/shuup/graphs/contributors/) 

**Category**: E-commerce

**Github**: [shuup/shuup](https://github.com/shuup/shuup)

**Website**: [shuup.com](https://shuup.com)

**Description**:
Headless e-commerce platform

**Alternative to**: [Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
