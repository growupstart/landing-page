
# Sylius 

<a href="https://sylius.com/"><img src="https://icons.duckduckgo.com/ip3/sylius.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/sylius/sylius.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/sylius/sylius/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/sylius/sylius.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/sylius/sylius/network/) [![GitHub issues](https://img.shields.io/github/issues/sylius/sylius.svg)](https://GitHub.com/Nsylius/sylius/issues/)

[![GitHub license](https://img.shields.io/github/license/sylius/sylius.svg)](https://github.com/sylius/sylius/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/sylius/sylius.svg)](https://GitHub.com/sylius/sylius/graphs/contributors/) 

**Category**: E-commerce

**Github**: [sylius/sylius](https://github.com/sylius/sylius)

**Website**: [sylius.com](https://sylius.com/)

**Description**:
Headless e-commerce platform

**Alternative to**: [Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
