
# Saleor 

<a href="https://saleor.io/"><img src="https://icons.duckduckgo.com/ip3/saleor.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/saleor/saleor.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/saleor/saleor/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/saleor/saleor.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/saleor/saleor/network/) [![GitHub issues](https://img.shields.io/github/issues/saleor/saleor.svg)](https://GitHub.com/Nsaleor/saleor/issues/)

[![GitHub license](https://img.shields.io/github/license/saleor/saleor.svg)](https://github.com/saleor/saleor/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/saleor/saleor.svg)](https://GitHub.com/saleor/saleor/graphs/contributors/) 

**Category**: E-commerce

**Github**: [saleor/saleor](https://github.com/saleor/saleor)

**Website**: [saleor.io](https://saleor.io/)

**Description**:
Headless e-commerce platform

**Alternative to**: [Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
