
# Bagisto 

<a href="https://bagisto.com/en/"><img src="https://icons.duckduckgo.com/ip3/bagisto.com/en.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/bagisto/bagisto.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/bagisto/bagisto/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/bagisto/bagisto.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/bagisto/bagisto/network/) [![GitHub issues](https://img.shields.io/github/issues/bagisto/bagisto.svg)](https://GitHub.com/Nbagisto/bagisto/issues/)

[![GitHub license](https://img.shields.io/github/license/bagisto/bagisto.svg)](https://github.com/bagisto/bagisto/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/bagisto/bagisto.svg)](https://GitHub.com/bagisto/bagisto/graphs/contributors/) 

**Category**: E-commerce

**Github**: [bagisto/bagisto](https://github.com/bagisto/bagisto)

**Website**: [bagisto.com/en](https://bagisto.com/en/)

**Description**:
Headless e-commerce platform

**Alternative to**: [Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
