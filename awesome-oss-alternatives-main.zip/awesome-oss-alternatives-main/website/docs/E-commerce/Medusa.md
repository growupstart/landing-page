
# Medusa 

<a href="https://www.medusajs.com/"><img src="https://icons.duckduckgo.com/ip3/www.medusajs.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/medusajs/medusa.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/medusajs/medusa/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/medusajs/medusa.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/medusajs/medusa/network/) [![GitHub issues](https://img.shields.io/github/issues/medusajs/medusa.svg)](https://GitHub.com/Nmedusajs/medusa/issues/)

[![GitHub license](https://img.shields.io/github/license/medusajs/medusa.svg)](https://github.com/medusajs/medusa/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/medusajs/medusa.svg)](https://GitHub.com/medusajs/medusa/graphs/contributors/) 

**Category**: E-commerce

**Github**: [medusajs/medusa](https://github.com/medusajs/medusa)

**Website**: [www.medusajs.com](https://www.medusajs.com/)

**Description**:
Headless e-commerce platform

**Alternative to**: [Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
