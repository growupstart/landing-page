
# Vendure 

<a href="https://www.vendure.io/"><img src="https://icons.duckduckgo.com/ip3/www.vendure.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/vendure-ecommerce/vendure.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/vendure-ecommerce/vendure/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/vendure-ecommerce/vendure.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/vendure-ecommerce/vendure/network/) [![GitHub issues](https://img.shields.io/github/issues/vendure-ecommerce/vendure.svg)](https://GitHub.com/Nvendure-ecommerce/vendure/issues/)

[![GitHub license](https://img.shields.io/github/license/vendure-ecommerce/vendure.svg)](https://github.com/vendure-ecommerce/vendure/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/vendure-ecommerce/vendure.svg)](https://GitHub.com/vendure-ecommerce/vendure/graphs/contributors/) 

**Category**: E-commerce

**Github**: [vendure-ecommerce/vendure](https://github.com/vendure-ecommerce/vendure)

**Website**: [www.vendure.io](https://www.vendure.io/)

**Description**:
Headless e-commerce platform

**Alternative to**: [Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
