
# Fusio 

<a href="https://github.com/apioo/fusio"><img src="https://icons.duckduckgo.com/ip3/github.com/apioo/fusio.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/apioo/fusio.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/apioo/fusio/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/apioo/fusio.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/apioo/fusio/network/) [![GitHub issues](https://img.shields.io/github/issues/apioo/fusio.svg)](https://GitHub.com/Napioo/fusio/issues/)

[![GitHub license](https://img.shields.io/github/license/apioo/fusio.svg)](https://github.com/apioo/fusio/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/apioo/fusio.svg)](https://GitHub.com/apioo/fusio/graphs/contributors/) 

**Category**: API Platform

**Github**: [apioo/fusio](https://github.com/apioo/fusio)

**Website**: [github.com/apioo/fusio](https://github.com/apioo/fusio)

**Description**:
API management platform

**Alternative to**: [Postman](https://www.postman.com/)
