
# Hoppscotch 

<a href="https://hoppscotch.io/"><img src="https://icons.duckduckgo.com/ip3/hoppscotch.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/hoppscotch/hoppscotch.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/hoppscotch/hoppscotch/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/hoppscotch/hoppscotch.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/hoppscotch/hoppscotch/network/) [![GitHub issues](https://img.shields.io/github/issues/hoppscotch/hoppscotch.svg)](https://GitHub.com/Nhoppscotch/hoppscotch/issues/)

[![GitHub license](https://img.shields.io/github/license/hoppscotch/hoppscotch.svg)](https://github.com/hoppscotch/hoppscotch/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/hoppscotch/hoppscotch.svg)](https://GitHub.com/hoppscotch/hoppscotch/graphs/contributors/) 

**Category**: API Platform

**Github**: [hoppscotch/hoppscotch](https://github.com/hoppscotch/hoppscotch)

**Website**: [hoppscotch.io](https://hoppscotch.io/)

**Description**:
API development ecosystem

**Alternative to**: [Postman](https://www.postman.com/)
