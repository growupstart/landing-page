
# OpenProject 

<a href="https://www.openproject.org/"><img src="https://icons.duckduckgo.com/ip3/www.openproject.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/opf/openproject.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/opf/openproject/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/opf/openproject.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/opf/openproject/network/) [![GitHub issues](https://img.shields.io/github/issues/opf/openproject.svg)](https://GitHub.com/Nopf/openproject/issues/)

[![GitHub license](https://img.shields.io/github/license/opf/openproject.svg)](https://github.com/opf/openproject/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/opf/openproject.svg)](https://GitHub.com/opf/openproject/graphs/contributors/) 

**Category**: Project Management

**Github**: [opf/openproject](https://github.com/opf/openproject)

**Website**: [www.openproject.org](https://www.openproject.org/)

**Description**:
Project management software

**Alternative to**: [Asana](https://asana.com/), [Trello](https://trello.com/)
