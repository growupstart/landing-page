
# Taiga 

<a href="https://www.taiga.io/"><img src="https://icons.duckduckgo.com/ip3/www.taiga.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/kaleidos-ventures/taiga-docker.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/kaleidos-ventures/taiga-docker/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/kaleidos-ventures/taiga-docker.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/kaleidos-ventures/taiga-docker/network/) [![GitHub issues](https://img.shields.io/github/issues/kaleidos-ventures/taiga-docker.svg)](https://GitHub.com/Nkaleidos-ventures/taiga-docker/issues/)

[![GitHub license](https://img.shields.io/github/license/kaleidos-ventures/taiga-docker.svg)](https://github.com/kaleidos-ventures/taiga-docker/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/kaleidos-ventures/taiga-docker.svg)](https://GitHub.com/kaleidos-ventures/taiga-docker/graphs/contributors/) 

**Category**: Project Management

**Github**: [kaleidos-ventures/taiga-docker](https://github.com/kaleidos-ventures/taiga-docker)

**Website**: [www.taiga.io](https://www.taiga.io/)

**Description**:
Project management software

**Alternative to**: [Asana](https://asana.com/), [Trello](https://trello.com/), [Jira](https://www.atlassian.com/software/jira)
