
# Focalboard 

<a href="https://www.focalboard.com/"><img src="https://icons.duckduckgo.com/ip3/www.focalboard.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/mattermost/focalboard.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/mattermost/focalboard/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/mattermost/focalboard.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/mattermost/focalboard/network/) [![GitHub issues](https://img.shields.io/github/issues/mattermost/focalboard.svg)](https://GitHub.com/Nmattermost/focalboard/issues/)

[![GitHub license](https://img.shields.io/github/license/mattermost/focalboard.svg)](https://github.com/mattermost/focalboard/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/mattermost/focalboard.svg)](https://GitHub.com/mattermost/focalboard/graphs/contributors/) 

**Category**: Project Management

**Github**: [mattermost/focalboard](https://github.com/mattermost/focalboard)

**Website**: [www.focalboard.com](https://www.focalboard.com/)

**Description**:
Alternative to Trello, Notion, and Asana

**Alternative to**: [Trello](https://trello.com/), [Notion](https://www.notion.so/), [Asana](https://asana.com/)
