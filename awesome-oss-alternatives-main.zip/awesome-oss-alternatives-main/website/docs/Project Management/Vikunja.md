
# Vikunja 

<a href="https://vikunja.io/"><img src="https://icons.duckduckgo.com/ip3/vikunja.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/go-vikunja/api.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/go-vikunja/api/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/go-vikunja/api.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/go-vikunja/api/network/) [![GitHub issues](https://img.shields.io/github/issues/go-vikunja/api.svg)](https://GitHub.com/Ngo-vikunja/api/issues/)

[![GitHub license](https://img.shields.io/github/license/go-vikunja/api.svg)](https://github.com/go-vikunja/api/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/go-vikunja/api.svg)](https://GitHub.com/go-vikunja/api/graphs/contributors/) 

**Category**: Project Management

**Github**: [go-vikunja/api](https://github.com/go-vikunja/api)

**Website**: [vikunja.io](https://vikunja.io/)

**Description**:
The to-do app to organize your next project.

**Alternative to**: [Todoist](https://todoist.com), [Trello](https://trello.com), [Asana](https://asana.com)
