
# ArangoDB 

<a href="https://www.arangodb.com/"><img src="https://icons.duckduckgo.com/ip3/www.arangodb.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/arangodb/arangodb.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/arangodb/arangodb/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/arangodb/arangodb.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/arangodb/arangodb/network/) [![GitHub issues](https://img.shields.io/github/issues/arangodb/arangodb.svg)](https://GitHub.com/Narangodb/arangodb/issues/)

[![GitHub license](https://img.shields.io/github/license/arangodb/arangodb.svg)](https://github.com/arangodb/arangodb/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/arangodb/arangodb.svg)](https://GitHub.com/arangodb/arangodb/graphs/contributors/) 

**Category**: Graph database

**Github**: [arangodb/arangodb](https://github.com/arangodb/arangodb)

**Website**: [www.arangodb.com](https://www.arangodb.com/)

**Description**:
Graph database and document store

**Alternative to**: [TigerGraph](https://www.tigergraph.com/), [Amazon Neptune](https://aws.amazon.com/neptune/)
