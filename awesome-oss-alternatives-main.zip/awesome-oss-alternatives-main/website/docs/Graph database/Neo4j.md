
# Neo4j 

<a href="http://neo4j.com/"><img src="https://icons.duckduckgo.com/ip3/neo4j.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/neo4j/neo4j.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/neo4j/neo4j/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/neo4j/neo4j.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/neo4j/neo4j/network/) [![GitHub issues](https://img.shields.io/github/issues/neo4j/neo4j.svg)](https://GitHub.com/Nneo4j/neo4j/issues/)

[![GitHub license](https://img.shields.io/github/license/neo4j/neo4j.svg)](https://github.com/neo4j/neo4j/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/neo4j/neo4j.svg)](https://GitHub.com/neo4j/neo4j/graphs/contributors/) 

**Category**: Graph database

**Github**: [neo4j/neo4j](https://github.com/neo4j/neo4j)

**Website**: [neo4j.com](http://neo4j.com/)

**Description**:
Graph database platform

**Alternative to**: [TigerGraph](https://www.tigergraph.com/), [Amazon Neptune](https://aws.amazon.com/neptune/)
