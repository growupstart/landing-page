
# RustDesk 

<a href="https://rustdesk.com/"><img src="https://icons.duckduckgo.com/ip3/rustdesk.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/rustdesk/rustdesk.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/rustdesk/rustdesk/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/rustdesk/rustdesk.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/rustdesk/rustdesk/network/) [![GitHub issues](https://img.shields.io/github/issues/rustdesk/rustdesk.svg)](https://GitHub.com/Nrustdesk/rustdesk/issues/)

[![GitHub license](https://img.shields.io/github/license/rustdesk/rustdesk.svg)](https://github.com/rustdesk/rustdesk/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/rustdesk/rustdesk.svg)](https://GitHub.com/rustdesk/rustdesk/graphs/contributors/) 

**Category**: Remote Desktop Application

**Github**: [rustdesk/rustdesk](https://github.com/rustdesk/rustdesk)

**Website**: [rustdesk.com](https://rustdesk.com/)

**Description**:
Open source virtual / remote desktop infrastructure for everyone

**Alternative to**: [TeamViewer](https://teamviewer.com)
