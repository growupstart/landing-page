
# Space Cloud 

<a href="https://space-cloud.io/"><img src="https://icons.duckduckgo.com/ip3/space-cloud.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/spacecloud-io/space-cloud.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/spacecloud-io/space-cloud/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/spacecloud-io/space-cloud.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/spacecloud-io/space-cloud/network/) [![GitHub issues](https://img.shields.io/github/issues/spacecloud-io/space-cloud.svg)](https://GitHub.com/Nspacecloud-io/space-cloud/issues/)

[![GitHub license](https://img.shields.io/github/license/spacecloud-io/space-cloud.svg)](https://github.com/spacecloud-io/space-cloud/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/spacecloud-io/space-cloud.svg)](https://GitHub.com/spacecloud-io/space-cloud/graphs/contributors/) 

**Category**: Platform as a service

**Github**: [spacecloud-io/space-cloud](https://github.com/spacecloud-io/space-cloud)

**Website**: [space-cloud.io](https://space-cloud.io/)

**Description**:
Serverless cloud deployment platform

**Alternative to**: [Heroku](https://www.heroku.com/)
