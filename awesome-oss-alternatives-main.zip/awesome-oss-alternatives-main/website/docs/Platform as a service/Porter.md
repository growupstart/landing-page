
# Porter 

<a href="https://porter.run/"><img src="https://icons.duckduckgo.com/ip3/porter.run.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/porter-dev/porter.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/porter-dev/porter/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/porter-dev/porter.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/porter-dev/porter/network/) [![GitHub issues](https://img.shields.io/github/issues/porter-dev/porter.svg)](https://GitHub.com/Nporter-dev/porter/issues/)

[![GitHub license](https://img.shields.io/github/license/porter-dev/porter.svg)](https://github.com/porter-dev/porter/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/porter-dev/porter.svg)](https://GitHub.com/porter-dev/porter/graphs/contributors/) 

**Category**: Platform as a service

**Github**: [porter-dev/porter](https://github.com/porter-dev/porter)

**Website**: [porter.run](https://porter.run/)

**Description**:
Kubernetes powered PaaS that runs in your own cloud

**Alternative to**: [Heroku](https://www.heroku.com/)
