
# Pulumi 

<a href="https://www.pulumi.com/"><img src="https://icons.duckduckgo.com/ip3/www.pulumi.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/pulumi/pulumi.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/pulumi/pulumi/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/pulumi/pulumi.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/pulumi/pulumi/network/) [![GitHub issues](https://img.shields.io/github/issues/pulumi/pulumi.svg)](https://GitHub.com/Npulumi/pulumi/issues/)

[![GitHub license](https://img.shields.io/github/license/pulumi/pulumi.svg)](https://github.com/pulumi/pulumi/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/pulumi/pulumi.svg)](https://GitHub.com/pulumi/pulumi/graphs/contributors/) 

**Category**: Platform as a service

**Github**: [pulumi/pulumi](https://github.com/pulumi/pulumi)

**Website**: [www.pulumi.com](https://www.pulumi.com/)

**Description**:
Universal Infrastructure as Code

**Alternative to**: [Heroku](https://www.heroku.com/)
