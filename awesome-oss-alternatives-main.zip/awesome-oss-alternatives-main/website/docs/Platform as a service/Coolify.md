
# Coolify 

<a href="https://coolify.io/"><img src="https://icons.duckduckgo.com/ip3/coolify.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/coollabsio/coolify.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/coollabsio/coolify/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/coollabsio/coolify.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/coollabsio/coolify/network/) [![GitHub issues](https://img.shields.io/github/issues/coollabsio/coolify.svg)](https://GitHub.com/Ncoollabsio/coolify/issues/)

[![GitHub license](https://img.shields.io/github/license/coollabsio/coolify.svg)](https://github.com/coollabsio/coolify/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/coollabsio/coolify.svg)](https://GitHub.com/coollabsio/coolify/graphs/contributors/) 

**Category**: Platform as a service

**Github**: [coollabsio/coolify](https://github.com/coollabsio/coolify)

**Website**: [coolify.io](https://coolify.io/)

**Description**:
Self-hostable Heroku alternative

**Alternative to**: [Heroku](https://www.heroku.com/)
