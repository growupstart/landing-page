
# Qovery 

<a href="https://www.qovery.com/"><img src="https://icons.duckduckgo.com/ip3/www.qovery.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Qovery/engine.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Qovery/engine/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Qovery/engine.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Qovery/engine/network/) [![GitHub issues](https://img.shields.io/github/issues/Qovery/engine.svg)](https://GitHub.com/NQovery/engine/issues/)

[![GitHub license](https://img.shields.io/github/license/Qovery/engine.svg)](https://github.com/Qovery/engine/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Qovery/engine.svg)](https://GitHub.com/Qovery/engine/graphs/contributors/) 

**Category**: Platform as a service

**Github**: [Qovery/engine](https://github.com/Qovery/engine)

**Website**: [www.qovery.com](https://www.qovery.com/)

**Description**:
Kubernetes powered PaaS that runs in your own cloud

**Alternative to**: [Heroku](https://www.heroku.com/)
