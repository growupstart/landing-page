
# Otomi 

<a href="https://otomi.io"><img src="https://icons.duckduckgo.com/ip3/otomi.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/redkubes/otomi-core.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/redkubes/otomi-core/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/redkubes/otomi-core.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/redkubes/otomi-core/network/) [![GitHub issues](https://img.shields.io/github/issues/redkubes/otomi-core.svg)](https://GitHub.com/Nredkubes/otomi-core/issues/)

[![GitHub license](https://img.shields.io/github/license/redkubes/otomi-core.svg)](https://github.com/redkubes/otomi-core/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/redkubes/otomi-core.svg)](https://GitHub.com/redkubes/otomi-core/graphs/contributors/) 

**Category**: Platform as a service

**Github**: [redkubes/otomi-core](https://github.com/redkubes/otomi-core)

**Website**: [otomi.io](https://otomi.io)

**Description**:
Self-hosted PaaS for Kubernetes

**Alternative to**: [Heroku](https://www.heroku.com/)
