
# RoboCorp 

<a href="https://robocorp.com/"><img src="https://icons.duckduckgo.com/ip3/robocorp.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/robocorp/rcc.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/robocorp/rcc/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/robocorp/rcc.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/robocorp/rcc/network/) [![GitHub issues](https://img.shields.io/github/issues/robocorp/rcc.svg)](https://GitHub.com/Nrobocorp/rcc/issues/)

[![GitHub license](https://img.shields.io/github/license/robocorp/rcc.svg)](https://github.com/robocorp/rcc/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/robocorp/rcc.svg)](https://GitHub.com/robocorp/rcc/graphs/contributors/) 

**Category**: Robotic Process Automation

**Github**: [robocorp/rcc](https://github.com/robocorp/rcc)

**Website**: [robocorp.com](https://robocorp.com/)

**Description**:
Set of tooling that allows to create automation packages

**Alternative to**: [UiPath](https://www.uipath.com/)
