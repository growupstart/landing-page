
# Vanilla 

<a href="https://vanillaforums.com/"><img src="https://icons.duckduckgo.com/ip3/vanillaforums.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/vanilla/vanilla.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/vanilla/vanilla/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/vanilla/vanilla.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/vanilla/vanilla/network/) [![GitHub issues](https://img.shields.io/github/issues/vanilla/vanilla.svg)](https://GitHub.com/Nvanilla/vanilla/issues/)

[![GitHub license](https://img.shields.io/github/license/vanilla/vanilla.svg)](https://github.com/vanilla/vanilla/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/vanilla/vanilla.svg)](https://GitHub.com/vanilla/vanilla/graphs/contributors/) 

**Category**: Forum Software

**Github**: [vanilla/vanilla](https://github.com/vanilla/vanilla)

**Website**: [vanillaforums.com](https://vanillaforums.com/)

**Description**:
A platform for community discussion

**Alternative to**: [Tribe](https://tribe.so/), [Circle](https://circle.so/)
