
# Discourse 

<a href="https://www.discourse.org/"><img src="https://icons.duckduckgo.com/ip3/www.discourse.org.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/discourse/discourse.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/discourse/discourse/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/discourse/discourse.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/discourse/discourse/network/) [![GitHub issues](https://img.shields.io/github/issues/discourse/discourse.svg)](https://GitHub.com/Ndiscourse/discourse/issues/)

[![GitHub license](https://img.shields.io/github/license/discourse/discourse.svg)](https://github.com/discourse/discourse/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/discourse/discourse.svg)](https://GitHub.com/discourse/discourse/graphs/contributors/) 

**Category**: Forum Software

**Github**: [discourse/discourse](https://github.com/discourse/discourse)

**Website**: [www.discourse.org](https://www.discourse.org/)

**Description**:
A platform for community discussion

**Alternative to**: [Tribe](https://tribe.so/), [Circle](https://circle.so/)
