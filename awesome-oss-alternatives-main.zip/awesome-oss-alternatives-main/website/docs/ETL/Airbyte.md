
# Airbyte 

<a href="https://airbyte.io/"><img src="https://icons.duckduckgo.com/ip3/airbyte.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/airbytehq/airbyte.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/airbytehq/airbyte/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/airbytehq/airbyte.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/airbytehq/airbyte/network/) [![GitHub issues](https://img.shields.io/github/issues/airbytehq/airbyte.svg)](https://GitHub.com/Nairbytehq/airbyte/issues/)

[![GitHub license](https://img.shields.io/github/license/airbytehq/airbyte.svg)](https://github.com/airbytehq/airbyte/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/airbytehq/airbyte.svg)](https://GitHub.com/airbytehq/airbyte/graphs/contributors/) 

**Category**: ETL

**Github**: [airbytehq/airbyte](https://github.com/airbytehq/airbyte)

**Website**: [airbyte.io](https://airbyte.io/)

**Description**:
Data integration platform

**Alternative to**: [Fivetran](https://fivetran.com/)
