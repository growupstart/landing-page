
# Kestra 

<a href="https://kestra.io/"><img src="https://icons.duckduckgo.com/ip3/kestra.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/kestra-io/kestra.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/kestra-io/kestra/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/kestra-io/kestra.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/kestra-io/kestra/network/) [![GitHub issues](https://img.shields.io/github/issues/kestra-io/kestra.svg)](https://GitHub.com/Nkestra-io/kestra/issues/)

[![GitHub license](https://img.shields.io/github/license/kestra-io/kestra.svg)](https://github.com/kestra-io/kestra/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/kestra-io/kestra.svg)](https://GitHub.com/kestra-io/kestra/graphs/contributors/) 

**Category**: ETL

**Github**: [kestra-io/kestra](https://github.com/kestra-io/kestra)

**Website**: [kestra.io](https://kestra.io/)

**Description**:
orchestration and scheduling platform

**Alternative to**: [Fivetran](https://fivetran.com/)
