
# Unleash 

<a href="https://www.getunleash.io/"><img src="https://icons.duckduckgo.com/ip3/www.getunleash.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Unleash/unleash.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Unleash/unleash/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Unleash/unleash.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Unleash/unleash/network/) [![GitHub issues](https://img.shields.io/github/issues/Unleash/unleash.svg)](https://GitHub.com/NUnleash/unleash/issues/)

[![GitHub license](https://img.shields.io/github/license/Unleash/unleash.svg)](https://github.com/Unleash/unleash/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Unleash/unleash.svg)](https://GitHub.com/Unleash/unleash/graphs/contributors/) 

**Category**: Feature flag and toggle management

**Github**: [Unleash/unleash](https://github.com/Unleash/unleash)

**Website**: [www.getunleash.io](https://www.getunleash.io/)

**Description**:
Feature flags platform

**Alternative to**: [LaunchDarkly](https://launchdarkly.com/)
