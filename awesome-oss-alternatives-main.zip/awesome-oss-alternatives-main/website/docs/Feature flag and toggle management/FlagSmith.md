
# FlagSmith 

<a href="https://flagsmith.com/"><img src="https://icons.duckduckgo.com/ip3/flagsmith.com.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/Flagsmith/flagsmith.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/Flagsmith/flagsmith/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/Flagsmith/flagsmith.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/Flagsmith/flagsmith/network/) [![GitHub issues](https://img.shields.io/github/issues/Flagsmith/flagsmith.svg)](https://GitHub.com/NFlagsmith/flagsmith/issues/)

[![GitHub license](https://img.shields.io/github/license/Flagsmith/flagsmith.svg)](https://github.com/Flagsmith/flagsmith/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/Flagsmith/flagsmith.svg)](https://GitHub.com/Flagsmith/flagsmith/graphs/contributors/) 

**Category**: Feature flag and toggle management

**Github**: [Flagsmith/flagsmith](https://github.com/Flagsmith/flagsmith)

**Website**: [flagsmith.com](https://flagsmith.com/)

**Description**:
Feature Flag & Remote Config Service

**Alternative to**: [LaunchDarkly](https://launchdarkly.com/)
