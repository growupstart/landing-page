
# GrowthBook 

<a href="https://www.growthbook.io/"><img src="https://icons.duckduckgo.com/ip3/www.growthbook.io.ico" alt="Avatar" width="30" height="30" /></a>

[![GitHub stars](https://img.shields.io/github/stars/growthbook/growthbook.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/growthbook/growthbook/stargazers/) [![GitHub forks](https://img.shields.io/github/forks/growthbook/growthbook.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/growthbook/growthbook/network/) [![GitHub issues](https://img.shields.io/github/issues/growthbook/growthbook.svg)](https://GitHub.com/Ngrowthbook/growthbook/issues/)

[![GitHub license](https://img.shields.io/github/license/growthbook/growthbook.svg)](https://github.com/growthbook/growthbook/blob/master/LICENSE) [![GitHub contributors](https://img.shields.io/github/contributors/growthbook/growthbook.svg)](https://GitHub.com/growthbook/growthbook/graphs/contributors/) 

**Category**: Feature flag and toggle management

**Github**: [growthbook/growthbook](https://github.com/growthbook/growthbook)

**Website**: [www.growthbook.io](https://www.growthbook.io/)

**Description**:
Feature flags and A/B testing

**Alternative to**: [LaunchDarkly](https://launchdarkly.com/)
