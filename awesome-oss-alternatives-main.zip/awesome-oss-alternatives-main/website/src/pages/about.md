---
title: About this project
---

# About this project

This project was born as a extension on top of [Awesome GitHub List](https://github.com/RunaCapital/awesome-oss-alternatives)
